#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#define n 2
#define true 1
#define false 0
int c=0;
int c1=0;
int tam=0;
int n1=0;
int cont;
int turno;
int bandera;
int band2=0,band3=0;
char matriz[30][30];
int aux=0;// validacion
int user=0;//usuario
int comienza=0;
int user1[3]={0,0,0};//vector de usuario para puntajes
int fila[1000],columna[1000];//2vectores para la seleccion random
//int pf=1,pc=1,pf2,pc2;//Posiciones para los puntos
int aux1=0;//validacion
int aux2;//guardamos el valor del puntaje para verificar si aumenta
int equis1=0;
int band=0;//contador de conexiones
int acum=0;
//int aux3=0,aux4=0;//verificador de lineas ocupadas
//int fin=0;//fin del juego, si no hay espacios disponibles (falta hacer)
int y,z,w;//variables
int atras;
int cont_jugadaspc;
int cont_jugadasj;
int partidas_ganadasj;
int partidas_perdidaspc;
int partidas_ganadaspc;
int partidas_perdidasj;
int partidas_empatej;
int partidas_empatepc;
int partidas_perdidaspc2;
int partidas_ganadaspc2;
int partidas_empatepc2;
int cont_jugadaspc2;
int coord[2];
void tablero_cb(GtkWidget *event_box, GdkEventButton *event, gpointer data);
int lineas_completar1(int i,int j);
int completar_cuadrado(int i, int j);
int lineas();
void buscar_posicion(int pf,int pc);
int lineas_totales(int pf,int pc);
void lineas_completar(int i,int j);
void archivo_estadisticas();
void pcLocal();
void pcOponente();
//ventanas
GtkBuilder *builder;
GtkWidget *box_tablero;
GtkWidget *crear_tablero();
GtkWidget *eventbox;
GtkWidget *modo;
GtkWidget *nombre;
GtkWidget *inicio;
GtkWidget *inicio_teclado;
GtkWidget *color;
GtkWidget *color_teclado;
GtkWidget *dialog;
GtkWidget *ventana_principal;
GtkWidget *window1;
GtkWidget *dimension;
GtkWidget *dimension_teclado;
GtkWidget *tablero;
GtkWidget *win_tablero;
GtkWidget *menu_mostrar_acerca;
GtkWidget *menu_mostrar_ayuda;	// identificador del objeto menu item ayuda
GtkWidget *menu_mostrar_acerca1;
GtkWidget *menu_mostrar_ayuda1;
GtkWidget *estadisticas2;
GtkWidget *menu_salir;
GtkWidget *nombre_pp;
GtkWidget *inicio_pp;
GtkWidget *color_pp;
GtkWidget *ganador;

//botones
GtkWidget *boton_nuevo_juego;
GtkWidget *boton_como_jugar1;
GtkWidget *boton_acercade1;
GtkWidget *boton_estadisticas1;
GtkWidget *boton_como_jugar;
GtkWidget *boton_estadisticas;
GtkWidget *boton_cerrar;
GtkWidget *boton_1;
GtkWidget *boton_2;
GtkWidget *siguiente;
GtkWidget *siguiente1;
GtkWidget *siguiente2;
GtkWidget *siguiente3;
GtkWidget *siguienteNombre;
GtkWidget *siguiente_nombre2;
GtkWidget *aleatorio_pc;
GtkWidget *menu_boton;
GtkWidget *estadisticas_cerrar;
//boton atras
GtkWidget *atras1;
GtkWidget *atras2;
GtkWidget *atras3;
GtkWidget *atras4;
GtkWidget *atras5;
GtkWidget *atras6;
GtkWidget *atras7;
GtkWidget *atrasNombre;
GtkWidget *atras_nombre2;
///otros botones
GtkWidget *teclado;
GtkWidget *aleatorio;
GtkWidget *boton_jp;
GtkWidget *boton_pp;
GtkWidget *teclado1;
GtkWidget *aleatorio1;
GtkWidget *boton_jugador;
GtkWidget *boton_pc;
GtkWidget *teclado2;
GtkWidget *aleatorio2;
GtkWidget *rojo;
GtkWidget *azul;
GtkWidget *boton_inicio;
GtkWidget *boton_inicio1;
GtkWidget *inicio_atras;
GtkWidget *boton_colorpp;
GtkWidget *boton_colorpp1;
GtkWidget *color_atras;
GtkWidget *estadisticas1;
GtkWidget *boton_salir;
GtkWidget *salir_tablero;
//dialogs
GtkWidget *dialogAyuda;// identificador de la ventana de diálogo de ayuda al juego
GtkWidget *dialogAcerca;
GtkWidget *dialogEstadisticas;
GtkWidget *dialogGanador;

//textos
GtkWidget *text;
GtkWidget *text1;
GtkWidget *nombrepc1;
GtkWidget *nombrepc2;
GtkWidget *inicio_tecl;
GtkWidget *label_turno;
GtkWidget *label_estado;
GtkWidget *label_inferior;
GtkWidget *label_color;
GtkWidget *label_mensaje;
GtkWidget *label_usuario;
GtkWidget *label_pc;
GtkWidget *label_usuario1;
GtkWidget *label_pc1;
GtkWidget *puntaje_usuario;
GtkWidget *puntaje_maquina;
GtkWidget *empate;



GtkWidget *dimension_ing;
GtkWidget *color_ingr;
GtkWidget *bienvenida;
GtkWidget *titulo;
GtkWidget *titulo1;
GtkWidget *titulo2;
GtkWidget *titulo3;
GtkWidget *titulo4;
GtkWidget *titulo5;
GtkWidget *titulo6;
GtkWidget *texto_principal;
GtkWidget *label_estadisticas;
GtkWidget *label_ganador1;
GtkWidget *label_ganador2;
GtkWidget *label_ganador3;
GtkWidget *label_ganador4;
GtkWidget *label_ganador5;
GtkWidget *label_ganador6;
GtkWidget *text_estadisticas;
//imagenes
GtkWidget *color_rojo;
GtkWidget *color_azul;
GtkWidget *boton_rojopp;
GtkWidget *boton_azulpp;
const gchar *pp1;
const gchar *pp2;
const gchar *buf;
const gchar *buf1;
char namepc[15];
char namepc2[15];
int tam;
/////////////////////gtk_button_set_label(GTK_BUTTON(iBoton1), "");
/////////////////////////gtk_button_set_label(GTK_BUTTON(iBoton2), "");///limpiar botones
///////////////////////gtk_button_set_label(GTK_BUTTON(iBoton3), "");
char *imagenes[] = {"./IMG/punto.png",
					"./IMG/espacio.png",
					"./IMG/horizontall.png",
					"./IMG/vert.png",
					"./IMG/rojo.png",
					"./IMG/azul.png"};
//funcion para cambio de turnos
void turnos(){
	printf("\n\n\n**************************");
	printf("\nTurno del Jugador:%d",user);
	if(user==1 && c1==1){//y color rojo
		printf("\nCOLOR: ROJO");
		gtk_label_set_text(GTK_LABEL(label_turno), "USUARIO CON COLOR ROJO");
		//gtk_label_set_text(GTK_LABEL(label_color), "ROJO");
	} else if(user==1 && c1==2){// y color azul
		printf("\nCOLOR: AZUL");
		gtk_label_set_text(GTK_LABEL(label_turno), "USUARIO CON COLOR AZUL");
		//gtk_label_set_text(GTK_LABEL(label_color), "AZUL");
	} else if(user==2 && c1==1){
		printf("\nCOLOR: AZUL");
		gtk_label_set_text(GTK_LABEL(label_color), "PC LOCAL CON COLOR AZUL");
		//gtk_label_set_text(GTK_LABEL(label_color), "AZUL");
	} else if(user==2 && c1==2){
		printf("\nCOLOR: ROJO");
		gtk_label_set_text(GTK_LABEL(label_color), "PC LOCAL CON COLOR ROJO");
		//gtk_label_set_text(GTK_LABEL(label_color), "ROJO");
	} else if(user==3 && c1==1){
			printf("\nCOLOR: AZUL");
			gtk_label_set_text(GTK_LABEL(label_color), "PC OPONENTE CON COLOR AZUL");
			//gtk_label_set_text(GTK_LABEL(label_color), "AZUL");
	} else if(user==3 && c1==2){
			printf("\nCOLOR: azul");
			gtk_label_set_text(GTK_LABEL(label_color), "PC OPONENTE CON COLOR azul");
			//gtk_label_set_text(GTK_LABEL(label_color), "ROJO");
	}
	printf("\n**************************\n");
}

//Actualiza matriz logica
void imprimir_matriz(){
	int i=0,j=0;
	for(i=0; i<n1; i++){
		for(j=0; j<n1; j++){
			printf("%c",matriz[i][j]);
		}
		printf("\n");

	}
}
//Impresion de puntajes y actualizacion de quien va ganando
void imprimir_puntajes(){
	gchar *p = g_strdup_printf("Puntaje Usuario: %d", user1[0]);
	gchar *p1 = g_strdup_printf("Puntaje Maquina: %d", user1[1]);
	printf("\nPuntaje del user 1:%d",user1[0]);
	gtk_label_set_text(GTK_LABEL(puntaje_usuario), p);
	if (user1[0]==user1[1]){//para empate
		printf("\n\tEmpate\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "EMPATE");
	}
	printf("\nPuntaje del user 2:%d",user1[1]);
	gtk_label_set_text(GTK_LABEL(puntaje_maquina), p1);
	if (user1[0]>user1[1]){//para empate
		printf("\n\tEl usuario va ganando\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "EL USUARIO VA GANANDO");
	}
	if (user1[0]<user1[1]){//para empate
		printf("\n\tLa maquina va ganando\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "LA MAQUINA VA GANANDO");
	}
	printf("\n");
}
//Impresion de puntajes y actualizacion de quien va ganando
void imprimir_puntajes1(){
	gchar *p5 = g_strdup_printf("Puntaje LOCAL: %d", user1[1]);
	gchar *p6 = g_strdup_printf("Puntaje OPONENTE: %d", user1[2]);
	printf("\nPuntaje del user 2:%d",user1[1]);
	gtk_label_set_text(GTK_LABEL(puntaje_usuario), p5);
	if (user1[1]==user1[2]){//para empate
		printf("\n\tEmpate\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "EMPATE");
	}
	printf("\nPuntaje del user 3:%d",user1[2]);
	gtk_label_set_text(GTK_LABEL(puntaje_maquina), p6);
	if (user1[1]>user1[2]){//para empate
		printf("\n\tpc local va ganando\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "PC LOCAL VA GANANDO");
	}
	if (user1[1]<user1[2]){//para empate
		printf("\n\tpc oponente va ganando\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "PC OP VA GANANDO");
	}
	printf("\n");
}

//Verifica si se formaron cuadrados
int verificar_cuadrado(int lf,int lc){
	int b1=false;
	band=0;
	if (matriz[lf][lc]=='-'){//si lo ultimo que conectaste fue un guion abajo
		if(matriz[lf-1][lc-1]=='|'){
			band++;
		}
		if(matriz[lf-2][lc]=='-'){
			band++;
		}
		if(matriz[lf-1][lc+1]=='|'){
			band++;
		}
		//printf("band es %d ",band);
		if (band==3){
			b1=true;
			user1[user-1]=user1[user-1]+10;
			printf("se completo un cuadrado");
			//band1=1;
			if (matriz[lf-1][lc]=='0'){
				//printf("%d",i-1);
				//printf("%d",j);
				if(user==1 && c1==1){
					matriz[lf-1][lc]='R';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[4]);
				} else if(user==1 && c1==2){
					matriz[lf-1][lc]='A';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[5]);
				} else if(user==2 && c1==1){
					matriz[lf-1][lc]='A';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[5]);
				} else if(user==2 && c1==2){
					matriz[lf-1][lc]='R';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[4]);
				} else if(user==3 && c1==1){
					matriz[lf-1][lc]='R';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[4]);
				} else if(user==3 && c1==1){
					matriz[lf-1][lc]='A';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[5]);
				}
			}
		}
		band=0;

		/// verificar cuadrados arriba
		if(matriz[lf+1][lc-1]=='|'){
			band++;
		}
		if(matriz[lf+2][lc]=='-'){
			band++;
		}
		if(matriz[lf+1][lc+1]=='|'){
			band++;
		}
		if (band==3){
			b1=true;
			user1[user-1]=user1[user-1]+10;
			printf("\nse completo un cuadrado\n");
			//band1=1;
			if(user==1 && c1==1){
				matriz[lf+1][lc]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf+1)),imagenes[4]);
			} else if(user==1 && c1==2){
				matriz[lf+1][lc]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf+1)),imagenes[5]);
			} else if(user==2 && c1==1){
				matriz[lf+1][lc]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf+1)),imagenes[5]);
			} else if(user==2 && c1==2){
				matriz[lf+1][lc]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf+1)),imagenes[4]);
			}  else if(user==3 && c1==1){
				matriz[lf-1][lc]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[4]);
			} else if(user==3 && c1==1){
				matriz[lf-1][lc]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[5]);
			}
		}
		band=0;
	// verificar conexion derecha vertical
	}else if(matriz[lf][lc]=='|'){//si lo ult que pusiste fue linea vertical
		if(matriz[lf-1][lc-1]=='-'){
			band++;
		}
		if(matriz[lf][lc-2]=='|'){
			band++;
		}
		if(matriz[lf+1][lc-1]=='-'){
			band++;
		}
		if (band==3){
			b1=true;
			user1[user-1]=user1[user-1]+10;
			printf("\nse completo un cuadrado\n");
			//band1=1;
			if(user==1 && c1==1){
				matriz[lf][lc-1]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc-1,lf)),imagenes[4]);
			} else if(user==1 && c1==2){
				matriz[lf][lc-1]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc-1,lf)),imagenes[5]);
			} else if(user==2 && c1==1){
				matriz[lf][lc-1]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc-1,lf)),imagenes[5]);
			} else if(user==2 && c1==2){
				matriz[lf][lc-1]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc-1,lf)),imagenes[4]);
			}  else if(user==3 && c1==1){
				matriz[lf-1][lc]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[4]);
			} else if(user==3 && c1==1){
				matriz[lf-1][lc]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[5]);
			}
		}
		band=0;
		//verificar conexion izquierda vert
		if(matriz[lf-1][lc+1]=='-'){
			band++;
		}
		if(matriz[lf][lc+2]=='|'){
			band++;
		}
		if(matriz[lf+1][lc+1]=='-'){
			band++;
		}
		if (band==3){
			b1=true;
			user1[user-1]=user1[user-1]+10;
			printf("\nse completo un cuadrado\n");
			//band1=1;
			if(user==1 && c1==1){
				matriz[lf][lc+1]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc+1,lf)),imagenes[4]);
			} else if(user==1 && c1==2){
				matriz[lf][lc+1]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc+1,lf)),imagenes[5]);
			} else if(user==2 && c1==1){
				matriz[lf][lc+1]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc+1,lf)),imagenes[5]);
			} else if(user==2 && c1==2){
				matriz[lf][lc+1]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc+1,lf)),imagenes[4]);
			}  else if(user==3 && c1==1){
				matriz[lf-1][lc]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[4]);
			} else if(user==3 && c1==1){
				matriz[lf-1][lc]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),lc,lf-1)),imagenes[5]);
			}
		}
		band=0;
	}
	imprimir_matriz();
	if (turno==1){
		imprimir_puntajes();
	}else{
		imprimir_puntajes1();
	}

	return b1;
	//cambio_turno(aux2);
}

//busca cuantas cajas se cerraron
void game_over(){
	cont=0;
	n1=tam+(tam-1);
	for(int i=0;i<n1;i++){
		for(int j=0;j<n1;j++){
			if(i%2!=0 && j%2!=0){
				if(matriz[i][j]=='R' || matriz[i][j]=='A'){
					cont++;
				}
			}
		}
	}
}
//impresion de puntos
void game_over1(){
	gchar *p = g_strdup_printf("Puntaje Usuario: %d", user1[0]);
	gchar *p1 = g_strdup_printf("Puntaje Maquina: %d", user1[1]);
	//gchar *nom = g_strdup_printf(" %s", buf);
	//gchar *nom1 = g_strdup_printf("%s", buf1);
	//int fin1=game_over1();
		if (user1[0]>user1[1]){//compara vector de puntaje
			printf("\nyou win");
			gtk_label_set_text(GTK_LABEL(label_ganador6), "GANO EL USUARIO");
			gtk_label_set_text(GTK_LABEL(label_ganador2), buf);
			gtk_label_set_text(GTK_LABEL(label_ganador3), p);
			partidas_ganadasj++;
			partidas_perdidaspc++;
			//archivo_estadisticas(buf,buf1);
		}else if(user1[0]<user1[1]){
			printf("\nyou lose");
			gtk_label_set_text(GTK_LABEL(label_ganador6), "GANO LA MAQUINA");
			gtk_label_set_text(GTK_LABEL(label_ganador2), buf1);
			gtk_label_set_text(GTK_LABEL(label_ganador3), p1);
			partidas_ganadaspc++;
			partidas_perdidasj++;
			//archivo_estadisticas(buf,buf1);
		}else{
			if (user1[0]==user1[1]){
				printf("\nit's a tie");
				gtk_label_set_text(GTK_LABEL(label_ganador6), "EMPATE");
				gtk_label_set_text(GTK_LABEL(label_ganador5), p);
				gtk_label_set_text(GTK_LABEL(label_ganador2), buf);
				gtk_label_set_text(GTK_LABEL(label_ganador3), buf1);
				gtk_label_set_text(GTK_LABEL(label_ganador4), p1);
				partidas_empatepc++;
				partidas_empatej++;
				//archivo_estadisticas(buf,buf1);
			}
		}
		gtk_widget_show_all(ganador);
}
//impresion puntos
void game_over2(){
	gchar *p3 = g_strdup_printf("Puntaje PC LOCAL: %d", user1[1]);
	gchar *p4 = g_strdup_printf("Puntaje PC OPONENTE: %d", user1[2]);
	//gchar *nom = g_strdup_printf(" %s", buf);
	//gchar *nom1 = g_strdup_printf("%s", buf1);
	//int fin1=game_over1();
		if (user1[1]>user1[2]){//compara vector de puntaje
			printf("\nyou win");
			gtk_label_set_text(GTK_LABEL(label_ganador6), "GANO PC LOCAL");
			gtk_label_set_text(GTK_LABEL(label_ganador2), namepc);
			gtk_label_set_text(GTK_LABEL(label_ganador3), p3);
			partidas_ganadaspc++;
			partidas_perdidaspc2++;
			//archivo_estadisticas(buf,buf1);
		}else if(user1[1]<user1[2]){
			printf("\nyou lose");
			gtk_label_set_text(GTK_LABEL(label_ganador6), "GANO PC OPONENTE");
			gtk_label_set_text(GTK_LABEL(label_ganador2), namepc2);
			gtk_label_set_text(GTK_LABEL(label_ganador3), p4);
			partidas_ganadaspc2++;
			partidas_perdidaspc++;
			//archivo_estadisticas(buf,buf1);
		}else{
			if (user1[1]==user1[2]){
				printf("\nit's a tie");
				gtk_label_set_text(GTK_LABEL(label_ganador6), "EMPATE");
				gtk_label_set_text(GTK_LABEL(label_ganador1), p3);
				gtk_label_set_text(GTK_LABEL(label_ganador2), namepc);
				gtk_label_set_text(GTK_LABEL(label_ganador3), namepc2);
				gtk_label_set_text(GTK_LABEL(label_ganador4), p4);
				partidas_empatepc++;
				partidas_empatepc2++;
				//archivo_estadisticas(buf,buf1);
			}
		}
		gtk_widget_show_all(ganador);
}
//archivo estadisticas
void archivo_estadisticas(){
	//char nom,nom1;
	if(bandera==1){
		char archivo[]="estadisticas.txt";
		FILE *a = fopen(archivo,"r");
		if(a==NULL){
			a=fopen(archivo,"w");
			char titulo[]="nombre-puntaje-cant jugadas-part ganadas-part perdidas-part empate";
			fprintf(a,"%s",titulo);
			fclose(a);
			a=fopen(archivo,"r");
		}
		if (turno==1){
			struct registro{
				const char *nombre;
				int puntaje;
				int cont_jug;
				int cont_ganadas;
				int cont_perdidas;
				int cont_empate;
				const char *nombre1;
				int puntaje1;
				int cont_jug1;
				int cont_ganadas1;
				int cont_perdidas1;
				int cont_empate1;
			}est;
			est.nombre="";
			est.nombre1="";
			//if ((a = fopen (archivo, "w")) != NULL) {

				//printf("ERROR");
			if(buf==est.nombre){
				a = fopen (archivo, "w");
					if(user1[0]>user1[1]){
						est.puntaje=user1[0];
						est.cont_jug=cont_jugadasj++;
						est.cont_ganadas=partidas_ganadasj++;
						fprintf(a,"\n%d - %d - %d ",est.puntaje,est.cont_jug,est.cont_ganadas);
					}else{
						est.cont_perdidas=partidas_perdidasj++;
						fprintf(a,"\n %d",est.cont_perdidas);
					}
			}


			if(buf!=est.nombre && buf1!=est.nombre1){
				if ((a = fopen (archivo, "a")) != NULL) {
					//
					est.nombre=buf;
					est.puntaje=user1[0];
					est.cont_jug=cont_jugadasj;
					est.cont_ganadas=partidas_ganadasj;
					est.cont_perdidas=partidas_perdidasj;
					est.cont_empate=partidas_empatej;

					est.nombre1=buf1;
					est.puntaje1=user1[1];
					est.cont_jug1=cont_jugadaspc;
					est.cont_ganadas1=partidas_ganadaspc;
					est.cont_perdidas1=partidas_perdidaspc;
					est.cont_empate1=partidas_empatepc;
					fprintf(a,"\n%s - %d - %d - %d - %d-%d",est.nombre,est.puntaje,est.cont_jug,est.cont_ganadas,est.cont_perdidas,est.cont_empate);
					fprintf(a,"\n%s - %d - %d - %d - %d -%d",est.nombre1,est.puntaje1,est.cont_jug1,est.cont_ganadas1,est.cont_perdidas1,est.cont_empate1);
				}

			}
			fclose(a);
		}
		cont_jugadasj++;
		cont_jugadaspc++;
	}
}
	/*}else{
		struct registro1{
			char *nombre2;
			int cont_jug2;
			int cont_ganadas2;
			int cont_perdidas2;
			int cont_empate2;
			char *nombre3;
			int cont_jugpc2;
			int cont_ganadas;
			int cont_perdidas1;
			int cont_empate1;
		}est;
		est.nombre="";
		est.nombre1="";
		//if ((a = fopen (archivo, "w")) != NULL) {

			//printf("ERROR");
		if(buf==est.nombre){
			a = fopen (archivo, "w");
				if(user1[0]>user1[1]){
					est.puntaje=user1[0];
					est.cont_jug=cont_jugadasj++;
					est.cont_ganadas=partidas_ganadasj++;
					fprintf(a,"\n%d - %d - %d ",est.puntaje,est.cont_jug,est.cont_ganadas);
				}else{
					est.cont_perdidas=partidas_perdidasj++;
					fprintf(a,"\n %d",est.cont_perdidas);
				}
		}


		if(buf!=est.nombre && buf1!=est.nombre1){
			if ((a = fopen (archivo, "a")) != NULL) {
				//
				est.nombre=buf;
				est.puntaje=user1[0];
				est.cont_jug=cont_jugadasj;
				est.cont_ganadas=partidas_ganadasj;
				est.cont_perdidas=partidas_perdidasj;
				est.cont_empate=partidas_empatej;

				est.nombre1=buf1;
				est.puntaje1=user1[1];
				est.cont_jug1=cont_jugadaspc;
				est.cont_ganadas1=partidas_ganadaspc;
				est.cont_perdidas1=partidas_perdidaspc;
				est.cont_empate1=partidas_empatepc;
				fprintf(a,"\n%s - %d - %d - %d - %d-%d",est.nombre,est.puntaje,est.cont_jug,est.cont_ganadas,est.cont_perdidas,est.cont_empate);
				fprintf(a,"\n%s - %d - %d - %d - %d -%d",est.nombre1,est.puntaje1,est.cont_jug1,est.cont_ganadas1,est.cont_perdidas1,est.cont_empate1);
			}

		}
		fclose(a);
	}
	cont_jugadasj++;
	cont_jugadaspc++;
	}
}*/


//Jugada de la maquina
/*void turno_pc (){
	user=2;
	bandera=0;
	turnos();
	int pf,pc,c;
	pf=rand()%n1;
	pc=rand()%n1;
	i=pf;
	j=pc;
	if(matriz[i][j]=='0' ){
		if (i%2!=0 && j%2==0 && i!='*' && j!='*'){//verificar fila o columna sea par, y no se encuentre fuera
				matriz[i][j]='|';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[3]);
				c=verificar_cuadrado(i,j);
		}else if(i%2==0 && j%2!=0 && i!='*' && j!='*'){
				matriz[i][j]='-';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[2]);
				//lf1=pf1;
				//lc1=pc1;
				c=verificar_cuadrado(i,j);
		}else{
			c=true;
		}
	}else{
		c=true;
	}
	printf("maquinaaaa %d %d",i,j);
	game_over();
	if(cont==((tam-1)*(tam-1))){
		game_over1();
		bandera=1;
		archivo_estadisticas();
	}else{
		if(c==true){
			turno_pc();
		}else if(c==false){
			user=1;
		}
	}
}*/
//busca numeros impares para comparar posiciones desde el medio (donde se coloca el color)
int buscar(int p){
    int auxiliar1;
    auxiliar1=rand()%(p);
    while(auxiliar1%2==0){
    	auxiliar1=rand()%(p);
    }
    return auxiliar1;
}
//cantidad de lineas alrededor de un punto
int lineas_totales(int pf,int pc){
    int auxiliar2=0;
	if(matriz[pf-1][pc]=='-' ){
		auxiliar2++;
	}
	if(matriz[pf+1][pc]=='-' ){
		auxiliar2++;
	}
	if(matriz[pf][pc-1]=='|' ){
		auxiliar2++;
	}
	if(matriz[pf][pc+1]=='|'){
		auxiliar2++;
	}
    return auxiliar2;
}
//ubicar las posiciones posibles y conectar
void lineas_completar(int i, int j){
	if(matriz[i-1][j]=='0'){
		i=i-1;
		if(i%2==0 && j%2!=0 && i!='*' && j!='*'){
			matriz[i][j]='-';
			gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[2]);
			c=verificar_cuadrado(i,j);
			coord[0]=i;
			coord[1]=j;
		}
	}
	if(matriz[i+1][j]=='0'){
		i=i+1;
		if(i%2==0 && j%2!=0 && i!='*' && j!='*'){
			matriz[i][j]='-';
			gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[2]);
			c=verificar_cuadrado(i,j);
			coord[0]=i;
			coord[1]=j;
		}
	}
	if(matriz[i][j-1]=='0'){
		j=j-1;
		if (i%2!=0 && j%2==0 && i!='*' && j!='*'){
			matriz[i][j]='|';
			gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[3]);
			c=verificar_cuadrado(i,j);
			coord[0]=i;
			coord[1]=j;
		}
	}
	if(matriz[i][j+1]=='0'){
		j=j+1;
		if (i%2!=0 && j%2==0 && i!='*' && j!='*'){
			matriz[i][j]='|';
			gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[3]);
			c=verificar_cuadrado(i,j);
			coord[0]=i;
			coord[1]=j;
		}
	}

}
//inteligencia principal, completar cuadrados siosi
int completar_cuadrado(int i,int j){
	int k;
	int m;
	int band_cuadrado=FALSE;
	for(k=0;k<n1;k++){
		for(m=0;m<n1;m++){
			if(k%2!=0 && m%2!=0){
				if(lineas_totales(k,m)==3){
					i=k;
					j=m;
					lineas_completar(i,j);
					band_cuadrado=TRUE;
					break;
				}
			}
		}
	}
	return band_cuadrado;
}
//lineas a completar con su conexion
int lineas_completar1(int i,int j){
	int equis=FALSE;
	if(matriz[i][j]=='0' ){
		if (i%2!=0 && j%2==0 && i!='*' && j!='*'){//verificar fila o columna sea par, y no se encuentre fuera
				matriz[i][j]='|';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[3]);
				equis=verificar_cuadrado(i,j);
				coord[0]=i;
				coord[1]=j;
		}else if(i%2==0 && j%2!=0 && i!='*' && j!='*'){
				matriz[i][j]='-';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[2]);
				equis=verificar_cuadrado(i,j);
				coord[0]=i;
				coord[1]=j;
		}else{
			equis=true;
		}
	}else{
		equis=true;
	}
	return equis;
}
//vector con posiciones finales libres
void posiciones_libres(){
	for (int k=0;k<n1;k++){
		for (int e=0;e<n1;e++){
			if(k%2!=0 && e%2!=0){
				if(matriz[k+1][e]=='0'){
					fila[z]=k+1;
					columna[z]=e;
					z++;
				}
				else if(matriz[k-1][e]=='0'){
					fila[z]=k-1;
					columna[z]=e;
					z++;
				}
				else if(matriz[k][e+1]=='0'){
					fila[z]=k;
					columna[z]=e+1;
					z++;
				}
				else if(matriz[k][e-1]=='0'){
					fila[z]=k;
					columna[z]=e-1;
					z++;
				}
			}
		}
	}
}
void turno_pc (){
	bandera=0;
	turnos();
	c=0;
	user=2;
	int i=0,j=0,banderitaMil;
	banderitaMil=completar_cuadrado(i,j);
	int m=n1-1;
	int p=m+1;
	if(banderitaMil==FALSE){
		bandera=0;
		i=buscar(p);
		j=buscar(p);
		while(lineas_totales(i,j)>=2 && lineas()<((tam-1)*(tam-1))){//3
			i=buscar(p);
			j=buscar(p);
		}//supongamos q salio del while
		printf("VALORESSSS NEW sonnn %d %d",i,j);
		if(lineas()<((tam-1)*(tam-1))){
			if(lineas_totales(i,j)<2){
				buscar_posicion(i,j);
			}
		}else{
			if(lineas()==((tam-1)*(tam-1))){
				printf("ENTRANDOOOOOO");
				posiciones_libres();
				w=rand()%(z);//z se carga al final de cada carga de losvectores, por ende el ultimo z++ no llevara ningun valor util.
				i=fila[w];
				j=columna[w];
				coord[0]=i;
				coord[1]=j;
				printf("maquinaaaa de vector %d %d",i,j);
				if (i%2!=0 && j%2==0 && i!='*' && j!='*'){//verificar fila o columna sea par, y no se encuentre fuera
						matriz[i][j]='|';
						gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[3]);
						c=verificar_cuadrado(i,j);
				}else if(i%2==0 && j%2!=0 && i!='*' && j!='*'){
						matriz[i][j]='-';
						gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[2]);
						c=verificar_cuadrado(i,j);
						//lf1=pf1;
						//lc1=pc1;

				}else{
					c=true;
				}
			}
		}

	}
	printf("maquinaaaa %d %d",i,j);
	if (turno==1){
		game_over();
		if(cont==((tam-1)*(tam-1))){
			bandera=1;
			game_over1();
			archivo_estadisticas();
		}else{
			if(c==true || equis1==true){
				turno_pc();
			}else if(c==false || equis1==false){
				user=1;
			}
		}
	}else if(turno==2){
		game_over();
		if(cont==((tam-1)*(tam-1))){
			bandera=1;
			game_over2();
			archivo_estadisticas();
		}else{
			if(c==true || equis1==true){
				if(user==2){
					pcLocal();
				}else if(user==3){
					pcOponente();
				}
			}else if(c==false || equis1==false){
				if(user==3){
					pcLocal();
				}else if (user==2){
					pcOponente();
				}
			}
		}
	}

}

void buscar_posicion(int pf,int pc){
	int aux_x=0;
	equis1=false;
	int buscar1=0,i=pf,j=pc;
	if(aux_x!=0){
		if(buscar1==1){
			i=i+1;
			j=pc;
			//j queda igual
		}
		if(buscar1==2){
			i=i-1;
			j=pc;
			//j queda igual
		}
		if(buscar1==3){
			j=j+1;
			i=pf;
			//i queda igual
		}
		if(buscar1==4){
			j=j-1;
			i=pf;
			//i queda igual
		}
	}else{
		buscar1=1+rand()%(4);//random entre los 4 posiciones posibles
		printf("%i",buscar1);
		if(buscar1==1){
			i=i+1;
			j=pc;
			//j queda igual
		}
		if(buscar1==2){
			i=i-1;
			j=pc;
			//j queda igual
		}
		if(buscar1==3){
			j=j+1;
			i=pf;
			//i queda igual
		}
		if(buscar1==4){
			j=j-1;
			i=pf;
			//i queda igual
		}

		while(matriz[i][j]!='0'){
			buscar1=1+rand()%(4);
			i=pf;
			j=pc;
			if(buscar1==1){
				i=i+1;
				j=pc;
				//j queda igual
			}
			if(buscar1==2){
				i=i-1;
				j=pc;
				//j queda igual
			}
			if(buscar1==3){
				j=j+1;
				i=pf;
				//i queda igual
			}
			if(buscar1==4){
				j=j-1;
				i=pf;
				//i queda igual
			}
		}
	}
	if(matriz[i][j]=='0'){
		if(pf-1==i && pf%2!=0 && pc%2!=0){//Arriba
			if(pf-2>=1){
				if(lineas_totales(pf-2,pc)!=2){
					pf=i;
					equis1=lineas_completar1(pf,pc);
				}
			}else{
				pf=i;
				equis1=lineas_completar1(pf,pc);
			}
		}
		if(pf+1==i && pf%2!=0 &&pc%2!=0){//Abajo
			if(pf+2<n1-1){
				if(lineas_totales(pf+2,pc)!=2){
					pf=i;
					equis1=lineas_completar1(pf,pc);
				}
			}else{
				pf=i;
				equis1=lineas_completar1(pf,pc);
			}
		}
		if(pc-1==j && pf%2!=0 && pc%2!=0){//Izquierda
			if(pc-2>=1){
				if(lineas_totales(pf,pc-2)!=2){
					pc=j;
					equis1=lineas_completar1(pf,pc);
				}
			}else{
				pc=j;
				equis1=lineas_completar1(pf,pc);
			}
		}
		if(pc+1==j && pf%2!=0 && pc%2!=0){//Derecha
			if(pc+2<n1-1){
				if(lineas_totales(pf,pc+2)!=2){
					pc=j;
					equis1=lineas_completar1(pf,pc);
				}
			}else{
				pc=j;
				equis1=lineas_completar1(pf,pc);
			}
		}
	}
	if(aux_x>4){
		buscar1=1+rand()%(4);
		if(buscar1==1){
			i=i+1;
			j=pc;
			//j queda igual
		}
		if(buscar1==2){
			i=i-1;
			j=pc;
			//j queda igual
		}
		if(buscar1==3){
			j=j+1;
			i=pf;
			//i queda igual
		}
		if(buscar1==4){
			j=j-1;
			i=pf;
			//i queda igual
		}
		while(matriz[i][j]!='0'){
			buscar1=1+rand()%(4);
			i=pf;
			j=pc;
			if(buscar1==1){
				i=i+1;
				j=pc;
				//j queda igual
			}
			if(buscar1==2){
				i=i-1;
				j=pc;
				//j queda igual
			}
			if(buscar1==3){
				j=j+1;
				i=pf;
				//i queda igual
			}
			if(buscar1==4){
				j=j-1;
				i=pf;
				//i queda igual
			}
		}
		pf=i;
		pc=j;
	}
	if(pc%2!=0 && pf%2!=0){
		aux_x++;
		buscar_posicion(pf,pc);
	}
}
//posiciones libres alrededor de i,j impar
int lineas(){
	int acum=0;
	for(int k=0;k<n1;k++){
		for(int e=0;e<n1;e++){
			if(k%2!=0 && e%2!=0){
				if(lineas_totales(k,e)>=2){
					acum++;
				}
			}
		}
	}
	return acum;
}
//pc local , archivos funciona
void pcLocal(){
	FILE *pcLocal;
	char archivo[30];
	int fila1, columna1, fila2, columna2;
	user=2;
	coord[0]=0;
	coord[1]=0;
	turnos();
	bandera=0;
	sprintf(archivo, "%s.txt", namepc);
	if (user==2){
		if ((pcLocal = fopen (archivo, "w")) != NULL) {
			turno_pc();
			printf("\nimprime %i,%i %s\n",coord[0],coord[1],archivo);
			if(coord[0]%2==0 && coord[1]%2!=0){
				fila1=coord[0];
				columna1=coord[1]-1;
				fila2=coord[0];
				columna2=coord[1]+1;
			}else if(coord[0]%2!=0 && coord[1]%2==0){
				fila1=coord[0]-1;
				columna1=coord[1];
				fila2=coord[0]+1;
				columna2=coord[1];
			}
			fprintf(pcLocal,"%d,%d\n",fila1,columna1);
			fprintf(pcLocal,"%d,%d",fila2,columna2);
			fclose(pcLocal);
		}
	}
}
//pc oponente no funciona bien, no se envia correctamente los parametros
void pcOponente(){

	FILE *pcOponente;
	int fila1, columna1, fila2, columna2;
	user=3;
	coord[0]=0;
	coord[1]=0;
	turnos();
	char archivo1[100];
	sprintf(archivo1, "%s.txt", namepc2);
	pcOponente=fopen(archivo1,"r");
	if (user==3){
		if ((pcOponente = fopen (archivo1, "w")) != NULL) {
			turno_pc();
			printf("\nimprime %i,%i %s\n",coord[0],coord[1],archivo1);
			if(coord[0]%2==0 && coord[1]%2!=0){
				fila1=coord[0];
				columna1=coord[1]-1;
				fila2=coord[0];
				columna2=coord[1]+1;
			}else if(coord[0]%2!=0 && coord[1]%2==0){
				fila1=coord[0]-1;
				columna1=coord[1];
				fila2=coord[0]+1;
				columna2=coord[1];
			}
			fprintf(pcOponente,"%d,%d\n",fila1,columna1);
			fprintf(pcOponente,"%d,%d",fila2,columna2);
			fclose(pcOponente);
		}
	}

}
//Verificar dimension del tablero y emite mensaje de error en caso de ingresar mal

void verificar_dimension(int dim1){
	if (dim1<3 || dim1>15 ){
		dialog = gtk_message_dialog_new(GTK_WINDOW(dimension_teclado),
					      GTK_DIALOG_DESTROY_WITH_PARENT,
					      GTK_MESSAGE_WARNING,
					      GTK_BUTTONS_OK,
					      "Error, ingrese un valor entre 3 o 15");
		gtk_window_set_title(GTK_WINDOW(dialog), "Error");
		gtk_dialog_run(GTK_DIALOG(dialog));
		gtk_widget_destroy(dialog);
	}else{
			tam=dim1;

			gtk_widget_show_all(modo);
			gtk_widget_hide(dimension_teclado);


	}
}

void boton_principal(GtkWidget *widget, gpointer data){
	gtk_widget_show_all(dimension);
	gtk_widget_hide(ventana_principal);
}
void boton_teclado(GtkWidget *widget, gpointer data){
	gtk_widget_show_all(dimension_teclado);
	gtk_widget_hide(dimension);

}
//Elige aleatoriamente la dimension del tablero
void boton_aleatorio(GtkWidget *widget, gpointer data){
	gtk_widget_hide(dimension);
	tam = (3+rand()%13);
	printf("dimension: %d",tam);
	gtk_widget_show_all(modo);

}
//Ventana donde el usuario ingresa la dimension
void boton_dim(GtkWidget *widget, gpointer data){
	const gchar *dim=gtk_entry_get_text(GTK_ENTRY(dimension_ing));
	int y;
	printf ("dimmmmm:  %s\n", dim);
	y=atoi(dim);
	printf ("dimmmmm new:  %d\n", y);
	verificar_dimension(y);
}
void jp(GtkWidget *widget, gpointer data){
	gtk_widget_show_all(nombre);
	gtk_widget_hide(modo);
	turno=1;
}

void pp(GtkWidget *widget, gpointer data){
	gtk_widget_show_all(nombre_pp);
	gtk_widget_hide(modo);
	turno=2;
}



void menu(GtkWidget *widget, gpointer data){
	gtk_entry_set_text (GTK_ENTRY(text), "");
	gtk_entry_set_text (GTK_ENTRY(text1), "");
	gtk_entry_set_text (GTK_ENTRY(nombrepc1), "");
	gtk_entry_set_text (GTK_ENTRY(nombrepc2), "");
	gtk_entry_set_text (GTK_ENTRY(dimension_ing), "");
	user=0;
	c1=0;
	user1[0]=0;
	user1[1]=0;
	user1[2]=0;
	comienza=0;
	cont_jugadaspc=0;
	cont_jugadasj=0;
	partidas_ganadasj=0;
	partidas_ganadaspc=0;
	partidas_perdidasj=0;
	partidas_perdidaspc=0;
	partidas_empatej=0;
	partidas_empatepc=0;
	//gtk_widget_hide(tablero);
	gtk_widget_destroy(eventbox);
	gtk_widget_show_all(ventana_principal);

}

//Ventana donde se ingresa quien comienza
void boton_teclado1(GtkWidget *widget, gpointer data){
	gtk_widget_show_all(inicio_teclado);
	gtk_widget_hide(inicio);
}
//Genera aleatoriamente quien comienza

void boton_aleatorio1(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio);
	comienza=1+rand()%2;
	printf("inicia random%d\n",comienza);
	gtk_widget_show_all(color);

}

void boton_aleatorio11(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio_pp);
	comienza=2+rand()%2;
	printf("inicia random%d\n",comienza);
	gtk_widget_show_all(color_pp);

}
void jugador(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio_teclado);
	gtk_widget_show_all(color);
	comienza=1;
}
void maquina(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio_teclado);
	gtk_widget_show_all(color);
	comienza=2;
}

//El usuario ingresa un color
void boton_teclado2(GtkWidget *widget, gpointer data){
	gtk_widget_hide(color);
	gtk_widget_show_all(color_teclado);
}
void rojo1(GtkWidget *widget, gpointer data){
	c1=1;
	gtk_widget_hide(color_teclado);
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);//llama a crear tablero
	gtk_widget_show_all(win_tablero);

}

void azul1(GtkWidget *widget, gpointer data){
	c1=2;
	gtk_widget_hide(color_teclado);
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);//llama a crear tablero
	gtk_widget_show_all(win_tablero);
}

void pc11(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio_pp);
	gtk_widget_show_all(color_pp);
	comienza=2;
}
void pc22(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio_pp);
	gtk_widget_show_all(color_pp);
	comienza=3;
}


//El usuario ingresa un color
void rojopp (GtkWidget *widget, gpointer data){
	c1=1;
	gtk_widget_hide(color_pp);
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);//llama a crear tablero
	gtk_widget_show_all(win_tablero);
}

void azulpp(GtkWidget *widget, gpointer data){
	c1=2;
	gtk_widget_hide(color_pp);
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);//llama a crear tablero
	gtk_widget_show_all(win_tablero);
}

//Opcion que genera aleatoriamente el color
void boton_aleatorio2(GtkWidget *widget, gpointer data){
	gtk_widget_hide(color);
	c1=1+rand()%2;
	printf("\nCOLOR ALEATORIO%d\n",c1);

	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);//llama a crear tablero
	gtk_widget_show_all(win_tablero);
}
//Ventana de dialogo para instrucciones del juego
static void mostrar_ayuda(GtkWidget *widget, gpointer data) {
	gtk_dialog_run(GTK_DIALOG(dialogAyuda) );// mostramos la ventana de diálogo
	gtk_widget_hide(GTK_WIDGET(dialogAyuda) );	// escondemos la ventana
}
//Ventana de dialogo acerca de los autores
static void mostrar_acerca(GtkWidget *widget, gpointer data) {
	gtk_dialog_run(GTK_DIALOG(dialogAcerca) );// mostramos la ventana de diálogo
	gtk_widget_hide(GTK_WIDGET(dialogAcerca) );	// escondemos la ventana
}
//Ingresa nombre de usuario y maquina
void boton1_clicked_cb(GtkWidget *widget, gpointer data) {
	namepc[0]='\0';
	buf = gtk_entry_get_text (GTK_ENTRY(text));
	buf1 = gtk_entry_get_text (GTK_ENTRY(text1));// leemos el texto introducido
	sprintf(namepc, "%s\n", buf1);
	printf ("El nombre del usuario es: %s\n", buf);
	printf ("El nombre de la compu es: %s\n", buf1);
//Comprobamos que se ingrese dos nombres
	if(strlen(buf)<1 || strlen(buf1)<1){
			  dialog = gtk_message_dialog_new(GTK_WINDOW(nombre),
			            GTK_DIALOG_DESTROY_WITH_PARENT,
			            GTK_MESSAGE_WARNING,
			            GTK_BUTTONS_OK,
			            "Debe completar los 2 nombres");
			  gtk_window_set_title(GTK_WINDOW(dialog), "ERROR");
			  gtk_dialog_run(GTK_DIALOG(dialog));
			  gtk_widget_destroy(dialog);
	}else{
		//Mostrar en el tablero los nombres
		gtk_label_set_text(GTK_LABEL(label_usuario1),"Nombre Usuario:");
		gtk_label_set_text(GTK_LABEL(label_pc1),"Nombre Pc:");
		gtk_label_set_text(GTK_LABEL(label_usuario),buf);
		gtk_label_set_text(GTK_LABEL(label_pc),buf1);

		gtk_widget_hide(nombre) ;//esconder ventana
		gtk_widget_show_all(inicio);

	}
	//gtk_entry_set_text (GTK_ENTRY(text), "");	// vaciamos la entrada de texto
	//gtk_entry_set_text (GTK_ENTRY(text1), "");	// vaciamos la entrada de texto
}

void boton2_clicked_cb(GtkWidget *widget, gpointer data) {
	namepc[0]='\0';
	namepc2[0]='\0';

	buf1 = gtk_entry_get_text (GTK_ENTRY(nombrepc1));
	pp2 = gtk_entry_get_text (GTK_ENTRY(nombrepc2));// leemos el texto introducido
	printf ("El nombre de la pc1 es: %s\n", buf1);
	sprintf(namepc, "%s\n", buf1);
	printf ("El nombre de la pc2 es: %s\n", pp2);
	sprintf(namepc2, "%s\n", pp2);
//Comprobamos que se ingrese dos nombres
	if(strlen(buf1)<1 || strlen(pp2)<1){
			  dialog = gtk_message_dialog_new(GTK_WINDOW(nombre_pp),
			            GTK_DIALOG_DESTROY_WITH_PARENT,
			            GTK_MESSAGE_WARNING,
			            GTK_BUTTONS_OK,
			            "Debe completar los 2 nombres");
			  gtk_window_set_title(GTK_WINDOW(dialog), "ERROR");
			  gtk_dialog_run(GTK_DIALOG(dialog));
			  gtk_widget_destroy(dialog);
	}else{
		//Mostrar en el tablero los nombres
		gtk_label_set_text(GTK_LABEL(label_usuario1),"Nombre PC LOCAL:");
		gtk_label_set_text(GTK_LABEL(label_pc1),"Nombre PC OPONENTE:");
		gtk_label_set_text(GTK_LABEL(label_usuario),buf1);
		gtk_label_set_text(GTK_LABEL(label_pc),pp2);

		gtk_widget_hide(nombre_pp) ;//esconder ventana
		gtk_widget_show_all(inicio_pp);
	}
	gtk_entry_set_text (GTK_ENTRY(nombrepc1), "");	// vaciamos la entrada de texto
	gtk_entry_set_text (GTK_ENTRY(nombrepc2), "");	// vaciamos la entrada de texto
}


void b_atras1(GtkWidget *widget, gpointer data){
	dialog = gtk_message_dialog_new(GTK_WINDOW(dimension),
				GTK_DIALOG_DESTROY_WITH_PARENT,
				GTK_MESSAGE_QUESTION,
				GTK_BUTTONS_YES_NO,
				"Estas seguro que desea salir?, no se guardara la partida actual.");
	gtk_window_set_title(GTK_WINDOW(dialog), "Salir?");
	if(gtk_dialog_run(GTK_DIALOG(dialog))==GTK_RESPONSE_YES){
		gtk_widget_hide(dimension);
		gtk_widget_show_all(ventana_principal);
	}
	gtk_widget_destroy(dialog);
}

void b_atras2(GtkWidget *widget, gpointer data){
	gtk_widget_hide(dimension_teclado);
	gtk_entry_set_text (GTK_ENTRY(dimension_ing), "");
	gtk_widget_show_all(dimension);
}

void b_atras3(GtkWidget *widget, gpointer data){
	gtk_widget_hide(modo);
	gtk_entry_set_text (GTK_ENTRY(dimension_ing), "");
	gtk_widget_show_all(dimension_teclado);

}
void b_nombre1(GtkWidget *widget, gpointer data){
	gtk_widget_hide(nombre);

	gtk_widget_show_all(modo);
	gtk_entry_set_text (GTK_ENTRY(text), "");
	gtk_entry_set_text (GTK_ENTRY(text1), "");

}

void b_nombre2(GtkWidget *widget, gpointer data){
	gtk_widget_hide(nombre_pp);

	gtk_widget_show_all(modo);
	gtk_entry_set_text (GTK_ENTRY(nombrepc1), "");
	gtk_entry_set_text (GTK_ENTRY(nombrepc2), "");

}
void b_atras4(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio);
	gtk_entry_set_text (GTK_ENTRY(text), "");
	gtk_entry_set_text (GTK_ENTRY(text1), "");
	gtk_widget_show_all(nombre);

}

void b_atras5(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio_teclado);
	gtk_widget_show_all(inicio);

}

void b_atras6(GtkWidget *widget, gpointer data){
	gtk_widget_hide(color);
	gtk_widget_show_all(inicio_teclado);
}
void b_atras7(GtkWidget *widget, gpointer data){
	gtk_widget_hide(color_teclado);
	gtk_widget_show_all(color);
}

void b_inicio_atras(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio_pp);
	gtk_entry_set_text (GTK_ENTRY(nombrepc1), "");
	gtk_entry_set_text (GTK_ENTRY(nombrepc2), "");
	gtk_widget_show_all(nombre_pp);
}
void b_color_atras(GtkWidget *widget, gpointer data){
	gtk_widget_hide(color_pp);
	gtk_widget_show_all(inicio_pp);
}


static void estadisticas(GtkWidget *widget, gpointer data){
	FILE *archivo= fopen("estadisticas.txt","r");
		char m;
		char *v;
		int s=0;

		while((m=fgetc(archivo))!=EOF){
			//char temporal[10000];
			//putchar(m);
			s++;
			//sprintf(v,"%d",m);

			//gtk_label_set_text(GTK_LABEL(text_estadisticas),m);
		}
		//printf("S ESSSSSSSSSSS%d",s);
		v=(char*)malloc(s+2*sizeof(char));
		fseek(archivo,0,SEEK_SET);
		strcpy(v," ");
		while((m=fgetc(archivo))!=EOF){
			char v1[2];
			sprintf(v1,"%c",m);
			strcat(v,v1);
		}


		gtk_label_set_text(GTK_LABEL(text_estadisticas),v);
		gtk_dialog_run(GTK_DIALOG(dialogEstadisticas) );// mostramos la ventana de diálogo

		fclose(archivo);
		free(v);
		gtk_widget_destroy(dialogEstadisticas);

}
void tablero_logico(){
	for(int i=0; i<n1; i++){
		for(int j=0; j<n1; j++){
			if (i%2==0 && j%2==0){//colocar los astericos en las posiciones de fila y columna que son multiplos de 2
				matriz[i][j]='*';//carga astericos//////
			}else{
				matriz[i][j]='0';//cargado de la matriz
			}
			printf("%c",matriz[i][j]);//imprimir matriz
		}
		printf("\n");

	}
}
void vaciar_tablerogtk(){
	for (int i = 0; i < n1; i++) {
		for (int j = 0; j < n1; j++) {
			if (i%2!=0 && j%2!=0){
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[1]);

			}
			if(i%2==0 && j%2!=0){
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[1]);

			}
			if(i%2!=0 && j%2==0){
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[1]);

			}
		}
	}
}
//tablero
void b_nuevo_juego(GtkWidget *widget, gpointer data){

	dialog = gtk_message_dialog_new(GTK_WINDOW(dimension_teclado),
			GTK_DIALOG_DESTROY_WITH_PARENT,
			GTK_MESSAGE_QUESTION,
			GTK_BUTTONS_YES_NO,
			"Esta seguro que desea iniciar un juevo nuevo?");
	gtk_window_set_title(GTK_WINDOW(dialog), "dots and boxes");
	if(gtk_dialog_run(GTK_DIALOG(dialog))==GTK_RESPONSE_YES){
		//Se limpia el contador de puntos
		user1[0]=0;
		user1[1]=0;
		//user=0;
		//c1=0;
		//turno=0;
		//tam=0;
		//n1=0;
		//gtk_widget_hide(tablero);
		tablero_logico();
		vaciar_tablerogtk();
		if(comienza==2){
			turno_pc();
		}else{
			user=1;
			//g_signal_connect(eventbox, "button-press-event", G_CALLBACK(tablero_cb),tablero);
		}

	}else{
		cont_jugadaspc=0;
		cont_jugadasj=0;
		partidas_ganadasj=0;
		partidas_ganadaspc=0;
		partidas_perdidasj=0;
		partidas_perdidaspc=0;
		partidas_empatej=0;
		partidas_empatepc=0;
	}
	gtk_widget_destroy(dialog);
}
//ganador
void b_nuevo_juego_principal(GtkWidget *widget, gpointer data){

	dialog = gtk_message_dialog_new(GTK_WINDOW(dimension_teclado),
				GTK_DIALOG_DESTROY_WITH_PARENT,
				GTK_MESSAGE_QUESTION,
				GTK_BUTTONS_YES_NO,
				"Esta seguro que desea iniciar un juevo nuevo?");
		gtk_window_set_title(GTK_WINDOW(dialog), "dots and boxes");
		if(gtk_dialog_run(GTK_DIALOG(dialog))==GTK_RESPONSE_YES){
			gtk_widget_hide(ganador);
			//Se limpia el contador de puntos
			user1[0]=0;
			user1[1]=0;
			//user=0;
			//c1=0;
			//turno=0;
			//tam=0;
			//n1=0;
			//gtk_widget_hide(tablero);
			tablero_logico();
			vaciar_tablerogtk();
			if(comienza==2){
				turno_pc();
			}else{
				user=1;
				//g_signal_connect(eventbox, "button-press-event", G_CALLBACK(tablero_cb),tablero);
			}

		}else{
			cont_jugadaspc=0;
			cont_jugadasj=0;
			partidas_ganadasj=0;
			partidas_ganadaspc=0;
			partidas_perdidasj=0;
			partidas_perdidaspc=0;
			partidas_empatej=0;
			partidas_empatepc=0;
		}
		gtk_widget_destroy(dialog);
}
//Jugada del usuario
void tablero_cb(GtkWidget *event_box, GdkEventButton *event, gpointer data){
	int b;
	user=1;
	turnos();
	bandera=0;
	int i=0,j=0;
	guint pf1,pc1;
	if (user==1 && c==false){
		//gtk_label_set_text(GTK_LABEL(label_turno),"Juega Usuario");
		pf1 = (GUINT_FROM_LE(event->y) / 75); //las imagenes tienen son 75x75pixeles
		pc1 = (GUINT_FROM_LE(event->x) / 75);
		i=pf1;
		j=pc1;
		gchar *temp = g_strdup_printf("Presiono la imagen coordenada [%d,%d]",pf1,pc1);
		gtk_label_set_text(GTK_LABEL(label_estado), temp);
		if(matriz[i][j]=='0' ){
			if (pf1%2!=0 && pc1%2==0 && pf1!='*' && pc1!='*'){//verificar fila o columna sea par, y no se encuentre fuera
					matriz[i][j]='|';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),pc1,pf1)),imagenes[3]);
					b=verificar_cuadrado(i,j);
			}else if(pf1%2==0 && pc1%2!=0 && pf1!='*' && pc1!='*'){
					matriz[i][j]='-';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),pc1,pf1)),imagenes[2]);
					//lf1=pf1;
					//lc1=pc1;
					b=verificar_cuadrado(i,j);
			}else{
				b=true;
			}
		}else{
			//Si al verificar no es un movimiento valido sale un mensaje de error.
			dialog = gtk_message_dialog_new(GTK_WINDOW(dimension_teclado),
							  GTK_DIALOG_DESTROY_WITH_PARENT,
							  GTK_MESSAGE_WARNING,
							  GTK_BUTTONS_OK,
							  "Error vuelva a ingresar");
			gtk_window_set_title(GTK_WINDOW(dialog), "Error");
			gtk_dialog_run(GTK_DIALOG(dialog));
			gtk_widget_destroy(dialog);
			b=true;
		}
		game_over();
		if(cont==((tam-1)*(tam-1))){
			game_over1();
			bandera=1;
			archivo_estadisticas();
		}else{
			if(b==true){
				user=1;
			}else if(b==false){
				turno_pc();
			}
		}
	}

}

//Creacion del tablero con interfaz y tablero logico
GtkWidget *crear_tablero(){
	int i, j;
	GtkWidget *imagen; //auxiliar para cargar la imagen

	eventbox = gtk_event_box_new();
	tablero = gtk_grid_new();
	n1=tam+(tam-1);//Formula  para agrandar tablero
	for (i = 0; i < n1; i++) {
		for (j = 0; j < n1; j++) {
			if (i%2==0 && j%2==0){
				imagen = gtk_image_new_from_file(imagenes[0]);
				gtk_grid_attach(GTK_GRID(tablero), GTK_WIDGET(imagen), j, i, 1, 1);
			}else{
				imagen = gtk_image_new_from_file(imagenes[1]);
				gtk_grid_attach(GTK_GRID(tablero), GTK_WIDGET(imagen), j, i, 1, 1);
			}
		}
	}
	tablero_logico();
	gtk_container_add(GTK_CONTAINER(eventbox), tablero);
	if (turno==1){
		if(comienza==2){
			turno_pc();
			cont_jugadaspc++;
			cont_jugadasj++;
			g_signal_connect(eventbox, "button-press-event", G_CALLBACK(tablero_cb),tablero);
		}else if(comienza==1){
			g_signal_connect(eventbox, "button-press-event", G_CALLBACK(tablero_cb),tablero);
			cont_jugadasj++;
			cont_jugadaspc++;
		}
	}else if(turno==2){
		if(comienza==2){
			pcLocal();
		}else if(comienza==3){
			printf("turno oponente");
			pcOponente();
		}
	}

	return eventbox;
}
//Funcion para salir
void cerrar (GtkWidget *object, gpointer   user_data){
	 printf("%s", (char*)user_data);
	cont_jugadaspc=0;
	cont_jugadasj=0;
	partidas_ganadasj=0;
	partidas_ganadaspc=0;
	partidas_perdidasj=0;
	partidas_perdidaspc=0;
	 gtk_main_quit();
}
void cerrar_ganador (GtkWidget *object, gpointer data){
	gtk_widget_hide(ganador);
	gtk_widget_show_all(tablero);
}
//Funcion para salir 2
void cerrar1 (GtkWidget *object, gpointer   user_data){
	 printf("%s", (char*)user_data);
	cont_jugadaspc=0;
	cont_jugadasj=0;
	partidas_ganadasj=0;
	partidas_ganadaspc=0;
	partidas_perdidasj=0;
	partidas_perdidaspc=0;
	 gtk_main_quit();
}
int main (int argc, char *argv[]){

	srand(time(NULL));
    guint ret;

    GError *error = NULL;

    gtk_init (&argc, &argv);

	builder = gtk_builder_new();
	//Se carga el builder
	ret = gtk_builder_add_from_file(builder, "lab4.glade", &error);
	if (ret == 0) {
		g_print("Error en la función gtk_builder_add_from_file:\n%s", error->message);
		return 1;
	}

	dialogAyuda = GTK_WIDGET(gtk_builder_get_object(builder, "ayudaa"));// leemos la ventana de diálogo de ayuda para el juego
	dialogAcerca = GTK_WIDGET(gtk_builder_get_object(builder, "acerca"));// leemos la ventana de diálogo de acerca para el juego
	dialogEstadisticas = GTK_WIDGET(gtk_builder_get_object(builder, "estadisticas"));
	//dialogGanador = GTK_WIDGET(gtk_builder_get_object(builder, "ganador"));
	text = GTK_WIDGET(gtk_builder_get_object(builder, "selnombre1"));
	text1 = GTK_WIDGET(gtk_builder_get_object(builder, "selnombre2"));
	inicio_tecl = GTK_WIDGET(gtk_builder_get_object(builder, "inicio_tecl"));
	color_ingr = GTK_WIDGET(gtk_builder_get_object(builder, "color_ingr"));
	dimension_ing=GTK_WIDGET(gtk_builder_get_object(builder,"dimension_ing"));

	char mensaje[20] = "el juego termino";
	char mensaje1[20] = "el juego termino";

	//Ventana principal
	ventana_principal = GTK_WIDGET(gtk_builder_get_object(builder, "ventana_principal"));
	g_signal_connect (ventana_principal, "destroy", G_CALLBACK (cerrar), mensaje);

	win_tablero = GTK_WIDGET(gtk_builder_get_object(builder, "tablero"));
	//g_signal_connect (win_tablero, "destroy", G_CALLBACK (cerrar), mensaje);

	//otras ventanas
	nombre = GTK_WIDGET(gtk_builder_get_object(builder, "nombre"));
	g_signal_connect(nombre, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	dimension = GTK_WIDGET(gtk_builder_get_object(builder, "dimension"));
	g_signal_connect(dimension, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	dimension_teclado = GTK_WIDGET(gtk_builder_get_object(builder, "dimension_teclado"));
	g_signal_connect(dimension_teclado, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	modo = GTK_WIDGET(gtk_builder_get_object(builder, "modo"));
	g_signal_connect(modo, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	inicio = GTK_WIDGET(gtk_builder_get_object(builder, "inicio"));
	g_signal_connect(inicio, "destroy", G_CALLBACK (gtk_main_quit), NULL);


	inicio_teclado = GTK_WIDGET(gtk_builder_get_object(builder, "inicio_teclado"));
	g_signal_connect(inicio_teclado, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	color = GTK_WIDGET(gtk_builder_get_object(builder, "color"));
	g_signal_connect(color, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	color_teclado = GTK_WIDGET(gtk_builder_get_object(builder, "color_teclado"));
	g_signal_connect(color_teclado, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	//ventanas pc vs pc
	nombre_pp = GTK_WIDGET(gtk_builder_get_object(builder, "nombre_pp"));
	g_signal_connect(nombre_pp, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	inicio_pp = GTK_WIDGET(gtk_builder_get_object(builder, "inicio_pp"));
	g_signal_connect(inicio_pp, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	color_pp = GTK_WIDGET(gtk_builder_get_object(builder, "color_pp"));
	g_signal_connect(color_pp, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	ganador = GTK_WIDGET(gtk_builder_get_object(builder, "ganador"));
	g_signal_connect(ganador, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	//Box donde estara el Tablero
	box_tablero = GTK_WIDGET(gtk_builder_get_object(builder, "box_tablero"));


	//Labels


	bienvenida = GTK_WIDGET(gtk_builder_get_object(builder, "textobienvenida"));
	titulo = GTK_WIDGET(gtk_builder_get_object(builder, "texto_titulo"));
	label_turno = GTK_WIDGET(gtk_builder_get_object(builder, "label_turno"));
	label_estado = GTK_WIDGET(gtk_builder_get_object(builder, "label_estado"));
	label_inferior = GTK_WIDGET(gtk_builder_get_object(builder, "label_inferior"));
	label_color = GTK_WIDGET(gtk_builder_get_object(builder, "label_color"));
	label_mensaje = GTK_WIDGET(gtk_builder_get_object(builder, "label_mensaje"));
	label_usuario = GTK_WIDGET(gtk_builder_get_object(builder, "label_usuario"));
	label_pc = GTK_WIDGET(gtk_builder_get_object(builder, "label_pc"));
	label_usuario1 = GTK_WIDGET(gtk_builder_get_object(builder, "label_usuario1"));
	label_pc1 = GTK_WIDGET(gtk_builder_get_object(builder, "label_pc1"));
	puntaje_usuario = GTK_WIDGET(gtk_builder_get_object(builder, "puntaje_usuario"));
	puntaje_maquina = GTK_WIDGET(gtk_builder_get_object(builder, "puntaje_maquina"));
	empate = GTK_WIDGET(gtk_builder_get_object(builder, "empate"));
	texto_principal = GTK_WIDGET(gtk_builder_get_object(builder, "texto_principal"));
	label_estadisticas = GTK_WIDGET(gtk_builder_get_object(builder, "label estadisticas"));
	label_ganador1 = GTK_WIDGET(gtk_builder_get_object(builder, "label_ganador1"));
	label_ganador2 = GTK_WIDGET(gtk_builder_get_object(builder, "label_ganador2"));
	label_ganador3 = GTK_WIDGET(gtk_builder_get_object(builder, "label_ganador3"));
	label_ganador4 = GTK_WIDGET(gtk_builder_get_object(builder, "label_ganador4"));
	label_ganador5 = GTK_WIDGET(gtk_builder_get_object(builder, "label_ganador5"));
	label_ganador6 = GTK_WIDGET(gtk_builder_get_object(builder, "label_ganador6"));
	text_estadisticas = GTK_WIDGET(gtk_builder_get_object(builder, "text_estadisticas"));
	nombrepc1 = GTK_WIDGET(gtk_builder_get_object(builder, "nombrepc1"));
	nombrepc2 = GTK_WIDGET(gtk_builder_get_object(builder, "nombrepc2"));

	//Imagenes
	color_rojo= GTK_WIDGET(gtk_builder_get_object(builder, "rojo1"));
	color_azul= GTK_WIDGET(gtk_builder_get_object(builder, "azul1"));


	//botoneessss

	////


	teclado = GTK_WIDGET(gtk_builder_get_object(builder, "teclado"));
	g_signal_connect(teclado, "clicked", G_CALLBACK (boton_teclado), NULL);

	aleatorio = GTK_WIDGET(gtk_builder_get_object(builder, "aleatorio"));
	g_signal_connect(aleatorio, "clicked", G_CALLBACK (boton_aleatorio), NULL);

	boton_jp = GTK_WIDGET(gtk_builder_get_object(builder, "boton_jp"));
	g_signal_connect(boton_jp, "clicked", G_CALLBACK (jp), NULL);

	boton_pp = GTK_WIDGET(gtk_builder_get_object(builder, "boton_pp"));
	g_signal_connect(boton_pp, "clicked", G_CALLBACK (pp), NULL);

	boton_jugador = GTK_WIDGET(gtk_builder_get_object(builder, "boton_jugador"));
	g_signal_connect(boton_jugador, "clicked", G_CALLBACK (jugador), NULL);

	boton_pc = GTK_WIDGET(gtk_builder_get_object(builder, "boton_pc"));
	g_signal_connect(boton_pc, "clicked", G_CALLBACK (maquina), NULL);

	rojo= GTK_WIDGET(gtk_builder_get_object(builder, "rojo"));
	g_signal_connect(rojo, "clicked", G_CALLBACK (rojo1), NULL);

	azul= GTK_WIDGET(gtk_builder_get_object(builder, "azul"));
	g_signal_connect(azul, "clicked", G_CALLBACK (azul1), NULL);

	boton_inicio = GTK_WIDGET(gtk_builder_get_object(builder, "boton_inicio"));
	g_signal_connect(boton_inicio, "clicked", G_CALLBACK (pc11), NULL);

	aleatorio_pc = GTK_WIDGET(gtk_builder_get_object(builder, "aleatorio_pc"));
	g_signal_connect(aleatorio_pc, "clicked", G_CALLBACK (boton_aleatorio11), NULL);

	boton_inicio1 = GTK_WIDGET(gtk_builder_get_object(builder, "boton_inicio1"));
	g_signal_connect(boton_inicio1, "clicked", G_CALLBACK (pc22), NULL);

	boton_colorpp= GTK_WIDGET(gtk_builder_get_object(builder, "boton_colorpp"));
	g_signal_connect(boton_colorpp, "clicked", G_CALLBACK (rojopp), NULL);

	boton_colorpp1= GTK_WIDGET(gtk_builder_get_object(builder, "boton_colorpp1"));
	g_signal_connect(boton_colorpp1, "clicked", G_CALLBACK (azulpp), NULL);

	boton_1= GTK_WIDGET(gtk_builder_get_object(builder, "boton_1"));
	g_signal_connect(boton_1, "clicked", G_CALLBACK (b_nuevo_juego_principal), NULL);

	/*boton_estadisticas= GTK_WIDGET(gtk_builder_get_object(builder, "boton_estadisticas"));
	g_signal_connect(boton_estadisticas, "clicked", G_CALLBACK (estadisticas), NULL);

	boton_salir= GTK_WIDGET(gtk_builder_get_object(builder, "boton_salir"));
	g_signal_connect(boton_salir, "clicked", G_CALLBACK (salir), NULL);*/

	atras1= GTK_WIDGET(gtk_builder_get_object(builder, "atras1"));
	g_signal_connect(atras1, "clicked", G_CALLBACK (b_atras1), NULL);

	atras2= GTK_WIDGET(gtk_builder_get_object(builder, "atras2"));
	g_signal_connect(atras2, "clicked", G_CALLBACK (b_atras2), NULL);

	atras3= GTK_WIDGET(gtk_builder_get_object(builder, "atras3"));
	g_signal_connect(atras3, "clicked", G_CALLBACK (b_atras3), NULL);

	atras4= GTK_WIDGET(gtk_builder_get_object(builder, "atras4"));
	g_signal_connect(atras4, "clicked", G_CALLBACK (b_atras4), NULL);

	atras5= GTK_WIDGET(gtk_builder_get_object(builder, "atras5"));
	g_signal_connect(atras5, "clicked", G_CALLBACK (b_atras5), NULL);

	atras6= GTK_WIDGET(gtk_builder_get_object(builder, "atras6"));
	g_signal_connect(atras6, "clicked", G_CALLBACK (b_atras6), NULL);

	atras7= GTK_WIDGET(gtk_builder_get_object(builder, "atras7"));
	g_signal_connect(atras7, "clicked", G_CALLBACK (b_atras7), NULL);

	atrasNombre=GTK_WIDGET(gtk_builder_get_object(builder,"atrasNombre"));
	g_signal_connect(atrasNombre,"clicked", G_CALLBACK(b_nombre1),NULL);

	atras_nombre2=GTK_WIDGET(gtk_builder_get_object(builder,"atras_nombre2"));
	g_signal_connect(atras_nombre2,"clicked", G_CALLBACK(b_nombre2),NULL);

	inicio_atras=GTK_WIDGET(gtk_builder_get_object(builder,"inicio_atras"));
	g_signal_connect(inicio_atras,"clicked", G_CALLBACK(b_inicio_atras),NULL);

	color_atras=GTK_WIDGET(gtk_builder_get_object(builder,"color_atras"));
	g_signal_connect(color_atras,"clicked", G_CALLBACK(b_color_atras),NULL);

	menu_boton = GTK_WIDGET(gtk_builder_get_object(builder, "menu_boton"));
	g_signal_connect(menu_boton, "clicked", G_CALLBACK (menu), NULL);


	teclado1 = GTK_WIDGET(gtk_builder_get_object(builder, "teclado1"));
	g_signal_connect(teclado1, "clicked", G_CALLBACK (boton_teclado1), NULL);

	aleatorio1 = GTK_WIDGET(gtk_builder_get_object(builder, "aleatorio1"));
	g_signal_connect(aleatorio1, "clicked", G_CALLBACK (boton_aleatorio1), NULL);

	teclado2 = GTK_WIDGET(gtk_builder_get_object(builder, "teclado2"));
	g_signal_connect(teclado2, "clicked", G_CALLBACK (boton_teclado2), NULL);

	aleatorio2 = GTK_WIDGET(gtk_builder_get_object(builder, "aleatorio2"));
	g_signal_connect(aleatorio2, "clicked", G_CALLBACK (boton_aleatorio2), NULL);

	////
	siguiente = GTK_WIDGET(gtk_builder_get_object(builder, "siguiente"));
	g_signal_connect(siguiente, "clicked", G_CALLBACK (boton_principal), NULL);

	siguiente1=GTK_WIDGET(gtk_builder_get_object(builder,"siguiente1"));
	g_signal_connect(siguiente1,"clicked", G_CALLBACK(boton_dim),NULL);

	siguienteNombre=GTK_WIDGET(gtk_builder_get_object(builder,"siguienteNombre"));
	g_signal_connect(siguienteNombre,"clicked", G_CALLBACK(boton1_clicked_cb),NULL);

	siguiente_nombre2=GTK_WIDGET(gtk_builder_get_object(builder,"siguiente_nombre2"));
	g_signal_connect(siguiente_nombre2,"clicked", G_CALLBACK(boton2_clicked_cb),NULL);

	boton_nuevo_juego=GTK_WIDGET(gtk_builder_get_object(builder,"boton_nuevo_juego"));
	g_signal_connect(boton_nuevo_juego,"clicked", G_CALLBACK(b_nuevo_juego),NULL);

	/*siguiente2=GTK_WIDGET(gtk_builder_get_object(builder,"siguiente2"));
	g_signal_connect(siguiente2,"clicked", G_CALLBACK(boton_teclado1),NULL);*/

	/*siguiente3=GTK_WIDGET(gtk_builder_get_object(builder,"siguiente3"));
	g_signal_connect(siguiente3,"clicked", G_CALLBACK(boton_teclado2),NULL);*/

	/*salir_tablero=GTK_WIDGET(gtk_builder_get_object(builder,"salir_tablero"));
	g_signal_connect(salir_tablero,"activate", G_CALLBACK(cerrar1),mensaje1);*/
	boton_salir= GTK_WIDGET(gtk_builder_get_object(builder, "boton_salir"));
	g_signal_connect(boton_salir, "clicked", G_CALLBACK (cerrar1), mensaje1);


	menu_mostrar_acerca = GTK_WIDGET(gtk_builder_get_object(builder, "boton_acercade1"));
	g_signal_connect(menu_mostrar_acerca, "clicked", G_CALLBACK (mostrar_acerca), NULL);

	menu_mostrar_ayuda = GTK_WIDGET(gtk_builder_get_object(builder, "boton_como_jugar1"));
	g_signal_connect(menu_mostrar_ayuda, "clicked", G_CALLBACK (mostrar_ayuda), NULL);

	estadisticas1 = GTK_WIDGET(gtk_builder_get_object(builder, "boton_estadisticas1"));
	g_signal_connect(estadisticas1, "clicked", G_CALLBACK (estadisticas), NULL);


	menu_mostrar_ayuda1 = GTK_WIDGET(gtk_builder_get_object(builder, "boton_como_jugar"));
	g_signal_connect(menu_mostrar_ayuda1, "clicked", G_CALLBACK (mostrar_ayuda), NULL);

	estadisticas2 = GTK_WIDGET(gtk_builder_get_object(builder, "boton_estadisticas"));
	g_signal_connect(estadisticas2, "clicked", G_CALLBACK (estadisticas), NULL);

	menu_salir = GTK_WIDGET(gtk_builder_get_object(builder, "boton_cerrar"));
	g_signal_connect(menu_salir, "clicked", G_CALLBACK (cerrar), mensaje);

	boton_2= GTK_WIDGET(gtk_builder_get_object(builder, "boton_2"));
	g_signal_connect(boton_2, "clicked", G_CALLBACK (cerrar_ganador), mensaje);





    /* Connect the destroy signal of the window to gtk_main_quit
     * When the window is about to be destroyed we get a notification and
     * stop the main GTK+ loop
     */
	g_signal_connect (ventana_principal, "destroy", G_CALLBACK (cerrar), mensaje);
    //g_signal_connect (window, "destroy", G_CALLBACK (cerrar), mensaje);

    /* make sure that everything, window and label, are visible */
    gtk_widget_show_all (ventana_principal);


    /* start the main loop, and let it rest there until the application is closed */
    gtk_main ();

    return 0;
 }

