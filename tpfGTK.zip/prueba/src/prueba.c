#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#define n 2
int c1=0;
int tam=0;
int n1=0;
guint i,j;
int band2=0,band3=0;
char matriz[30][30];
int aux=0;// validacion
int user=0;//usuario
int user1[2]={0,0};//vector de usuario para puntajes
int fila[1000],columna[1000];//2vectores para la seleccion random
int pf1=1,pc1=1,pf2,pc2;//Posiciones para los puntos
int aux1=0;//validacion
int aux2;//guardamos el valor del puntaje para verificar si aumenta
int lf1,lc1;//guardar punto
int band=0;//contador de conexiones
//int aux3=0,aux4=0;//verificador de lineas ocupadas
int fin=0;//fin del juego, si no hay espacios disponibles (falta hacer)
int y,z,w;//variables
//ventanas
GtkBuilder *builder;
GtkWidget *box_tablero;
GtkWidget *crear_tablero();
GtkWidget *inicio;
GtkWidget *inicio_teclado;
GtkWidget *color;
GtkWidget *color_teclado;
GtkWidget *dialog;
GtkWidget *ventana_principal;
GtkWidget *window1;
GtkWidget *dimension;
GtkWidget *dimension_teclado;
GtkWidget *tablero;
GtkWidget *win_tablero;
GtkWidget *menu_mostrar_acerca;
GtkWidget *menu_mostrar_ayuda;	// identificador del objeto menu item ayuda
GtkWidget *menu_salir;
//botones
GtkWidget *siguiente;
GtkWidget *siguiente1;
GtkWidget *siguiente2;
GtkWidget *siguiente3;
GtkWidget *teclado;
GtkWidget *aleatorio;
GtkWidget *teclado1;
GtkWidget *aleatorio1;
GtkWidget *teclado2;
GtkWidget *aleatorio2;
GtkWidget *salir_tablero;
//dialogs
GtkWidget *dialogAyuda;// identificador de la ventana de diálogo de ayuda al juego
GtkWidget *dialogAcerca;
//textos
GtkWidget *text;
GtkWidget *text1;
GtkWidget *inicio_tecl;
GtkWidget *label_turno;
GtkWidget *label_estado;
GtkWidget *label_inferior;
GtkWidget *label_color;
GtkWidget *label_mensaje;
GtkWidget *label_usuario;
GtkWidget *label_pc;
GtkWidget *label_usuario1;
GtkWidget *label_pc1;
GtkWidget *puntaje_usuario;
GtkWidget *puntaje_maquina;
GtkWidget *empate;


GtkWidget *dimension_ing;
GtkWidget *color_ingr;
GtkWidget *bienvenida;
GtkWidget *titulo;
GtkWidget *titulo1;
GtkWidget *titulo2;
GtkWidget *titulo3;
GtkWidget *titulo4;
GtkWidget *titulo5;
GtkWidget *titulo6;

int tam;
char *imagenes[] = {"./IMG/punto.png",
					"./IMG/espacio.png",
					"./IMG/horizontall.png",
					"./IMG/vert.png",
					"./IMG/rojo.png",
					"./IMG/azul.png"};
//funcion para cambio de turnos
void turnos(){
	printf("\n\n\n**************************");
	printf("\nTurno del Jugador:%d",user);
	if(user==1 && c1==1){//y color rojo
		printf("\nCOLOR: ROJO");
		gtk_label_set_text(GTK_LABEL(label_turno), "USUARIO CON COLOR ROJO");
		//gtk_label_set_text(GTK_LABEL(label_color), "ROJO");
	} else if(user==1 && c1==2){// y color azul
		printf("\nCOLOR: AZUL");
		gtk_label_set_text(GTK_LABEL(label_turno), "USUARIO CON COLOR AZUL");
		//gtk_label_set_text(GTK_LABEL(label_color), "AZUL");
	} else if(user==2 && c1==1){
		printf("\nCOLOR: AZUL");
		gtk_label_set_text(GTK_LABEL(label_color), "MAQUINA CON COLOR AZUL");
		//gtk_label_set_text(GTK_LABEL(label_color), "AZUL");
	} else if(user==2 && c1==2){
		printf("\nCOLOR: ROJO");
		gtk_label_set_text(GTK_LABEL(label_color), "MAQUINA CON COLOR ROJO");
		//gtk_label_set_text(GTK_LABEL(label_color), "ROJO");
	}
	printf("\n**************************\n");
}
//Falta programar
void game_over(int fin1){
	if (fin1==1){
		if (user1[0]>user1[1]){//compara vector de puntaje
			printf("\nyou win");
			gtk_label_set_text(GTK_LABEL(label_mensaje), "GANO EL USUARIO");
		}else if(user1[0]<user1[1]){
			printf("\nyou lose");
			gtk_label_set_text(GTK_LABEL(label_mensaje), "GANO LA MAQUINA");
		}else{
			printf("\nit's a tie");
			gtk_label_set_text(GTK_LABEL(label_mensaje), "EMPATE");
		}
	}
}
//Falta programar
void game_over1(){
	//fin=0;
	//para que cambie en 1 si solo si en el siguente for encuentra una jugada posible
	for (i=0;i<n1;i++){
		for (j=0;j<n1;j++){
			if(i%2!=0 && j%2!=0){
				if(matriz[i][j]!='0' && (matriz[i][j]=='R' || matriz[i][j]=='A')){
					fin=1;//condicion para que el juego no continue
					game_over(fin);

				}else{
					fin=0;
				}
			}
		}

	}
	//printf("\nfin es %d\n",fin);

}
//Actualiza matriz logica
void imprimir_matriz(){
	for(i=0; i<n1; i++){
		for(j=0; j<n1; j++){
			printf("%c",matriz[i][j]);
		}
		printf("\n");

	}
}
//Impresion de puntajes y actualizacion de quien va ganando
void imprimir_puntajes(){
	gchar *p = g_strdup_printf("Puntaje Usuario: %d", user1[0]);
	gchar *p1 = g_strdup_printf("Puntaje Maquina: %d", user1[1]);
	printf("\nPuntaje del user 1:%d",user1[0]);
	gtk_label_set_text(GTK_LABEL(puntaje_usuario), p);
	if (user1[0]==user1[1]){//para empate
		printf("\n\tEmpate\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "EMPATE");
	}
	printf("\nPuntaje del user 2:%d",user1[1]);
	gtk_label_set_text(GTK_LABEL(puntaje_maquina), p1);
	if (user1[0]>user1[1]){//para empate
		printf("\n\tEl usuario va ganando\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "EL USUARIO VA GANANDO");
	}
	if (user1[0]<user1[1]){//para empate
		printf("\n\tLa maquina va ganando\n");
		gtk_label_set_text(GTK_LABEL(label_mensaje), "LA MAQUINA VA GANANDO");
	}
	printf("\n");
}

/*void cambio_turno(int aux5){
	if (user==1){//cambio de turno
		if(aux5==user1[user-1]){// si puntaje anterior es igual al puntaje nuevo, juega maquina, si cambia entonces vuelve a jugar
			user=2;
		}else if(aux5!=user1[user-1]){
			user=1;
		}
	}else{
		if(aux5==user1[user-1]){// si puntaje anterior es igual al puntaje nuevo, juega usuario, si cambia entonces vuelve a jugar
			user=1;
		}else if(aux5!=user1[user-1]){
			user=2;
		}
	}
}*/
//Verifica si se formaron cuadrados
void verificar_cuadrado(int lf,int lc){
	band=0;
	if (matriz[lf][lc]=='-'){//si lo ultimo que conectaste fue un guion abajo
		if(matriz[lf-1][lc-1]=='|'){
			band++;
		}
		if(matriz[lf-2][lc]=='-'){
			band++;
		}
		if(matriz[lf-1][lc+1]=='|'){
			band++;
		}
		//printf("band es %d ",band);
		if (band==3){
			user1[user-1]=user1[user-1]+10;
			printf("se completo un cuadrado");
			//band1=1;
			if (matriz[lf-1][lc]=='0'){
				//printf("%d",i-1);
				//printf("%d",j);
				if(user==1 && c1==1){
					matriz[lf-1][lc]='R';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i-1)),imagenes[4]);
				} else if(user==1 && c1==2){
					matriz[lf-1][lc]='A';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i-1)),imagenes[5]);
				} else if(user==2 && c1==1){
					matriz[lf-1][lc]='A';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i-1)),imagenes[5]);
				} else if(user==2 && c1==2){
					matriz[lf-1][lc]='R';
					gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i-1)),imagenes[4]);
				}
			}
		}
		band=0;
		/// verificar cuadrados arriba
		if(matriz[lf+1][lc-1]=='|'){
			band++;
		}
		if(matriz[lf+2][lc]=='-'){
			band++;
		}
		if(matriz[lf+1][lc+1]=='|'){
			band++;
		}
		if (band==3){
			user1[user-1]=user1[user-1]+10;
			printf("\nse completo un cuadrado\n");
			//band1=1;
			if(user==1 && c1==1){
				matriz[lf+1][lc]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i+1)),imagenes[4]);
			} else if(user==1 && c1==2){
				matriz[lf+1][lc]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i+1)),imagenes[5]);
			} else if(user==2 && c1==1){
				matriz[lf+1][lc]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i+1)),imagenes[5]);
			} else if(user==2 && c1==2){
				matriz[lf+1][lc]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i+1)),imagenes[4]);
			}
		}
		band=0;
	// verificar conexion derecha vertical
	}else if(matriz[lf][lc]=='|'){//si lo ult que pusiste fue linea vertical
		if(matriz[lf-1][lc-1]=='-'){
			band++;
		}
		if(matriz[lf][lc-2]=='|'){
			band++;
		}
		if(matriz[lf+1][lc-1]=='-'){
			band++;
		}
		if (band==3){
			user1[user-1]=user1[user-1]+10;
			printf("\nse completo un cuadrado\n");
			//band1=1;
			if(user==1 && c1==1){
				matriz[lf][lc-1]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j-1,i)),imagenes[4]);
			} else if(user==1 && c1==2){
				matriz[lf][lc-1]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j-1,i)),imagenes[5]);
			} else if(user==2 && c1==1){
				matriz[lf][lc-1]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j-1,i)),imagenes[5]);
			} else if(user==2 && c1==2){
				matriz[lf][lc-1]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j-1,i)),imagenes[4]);
			}
		}
		band=0;
		//verificar conexion izquierda vert
		if(matriz[lf-1][lc+1]=='-'){
			band++;
		}
		if(matriz[lf][lc+2]=='|'){
			band++;
		}
		if(matriz[lf+1][lc+1]=='-'){
			band++;
		}
		if (band==3){
			user1[user-1]=user1[user-1]+10;
			printf("\nse completo un cuadrado\n");
			//band1=1;
			if(user==1 && c1==1){
				matriz[lf][lc+1]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j+1,i)),imagenes[4]);
			} else if(user==1 && c1==2){
				matriz[lf][lc+1]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j+1,i)),imagenes[5]);
			} else if(user==2 && c1==1){
				matriz[lf][lc+1]='A';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j+1,i)),imagenes[5]);
			} else if(user==2 && c1==2){
				matriz[lf][lc+1]='R';
				gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j+1,i)),imagenes[4]);
			}
		}
		band=0;
	}
	imprimir_matriz();
	imprimir_puntajes();

	aux2=user1[user-1];
	//cambio_turno(aux2);
}

//Guarda el puntaje si esta en la posicion valida
void punto(int pf1,int pc1){
	turnos();
	//while (aux1==0){
	if (pf1%2!=0 && pc1%2==0 && pf1!='*' && pc1!='*'){//verificar fila o columna sea par, y no se encuentre fuera
		if(matriz[pf1][pc1]=='0' ){
			matriz[pf1][pc1]='|';
			gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[3]);

			lf1=pf1;
			lc1=pc1;
			verificar_cuadrado(lf1,lc1);
		}
	}else if(pf1%2==0 && pc1%2!=0 && pf1!='*' && pc1!='*'){
		if(matriz[pf1][pc1]=='0'){
			fin=0;
			matriz[pf1][pc1]='-';
			gtk_image_set_from_file(GTK_IMAGE(gtk_grid_get_child_at(GTK_GRID(tablero),j,i)),imagenes[2]);

			lf1=pf1;
			lc1=pc1;
			verificar_cuadrado(lf1,lc1);
		}
	}


}
/*void movimiento_usuario(){
	while (x==1){

	}
}*/
//Jugada de la maquina
void turno_pc (){
	user=2;
	i=rand()%n1;
	j=rand()%n1;
	printf("maquinaaaa %d %d",i,j);
			//gchar *temp = g_strdup_printf("Presiono la imagen coordenada [%d,%d]", i,j);
	punto(i,j);

			//gtk_label_set_text(GTK_LABEL(label_estado), temp);


}
//Verificar dimension del tablero y emite mensaje de error en caso de ingresar mal
void verificar_dimension(int dim1){
	if (dim1<3 || dim1>15 ){
		dialog = gtk_message_dialog_new(GTK_WINDOW(dimension_teclado),
					      GTK_DIALOG_DESTROY_WITH_PARENT,
					      GTK_MESSAGE_WARNING,
					      GTK_BUTTONS_OK,
					      "Error, ingrese un valor entre 3 o 15");
		gtk_window_set_title(GTK_WINDOW(dialog), "Error");
		gtk_dialog_run(GTK_DIALOG(dialog));
		gtk_widget_destroy(dialog);
	}else{
			gtk_widget_show_all(inicio);
			tam=dim1;
			gtk_widget_hide(dimension_teclado);
	}
}
//Verifica si se ingresa correctamente quien comienza el juego
void verificar_inicio(int turn1){
	if (turn1<1 || turn1>2){
		dialog = gtk_message_dialog_new(GTK_WINDOW(inicio_teclado),
									  GTK_DIALOG_DESTROY_WITH_PARENT,
									  GTK_MESSAGE_WARNING,
									  GTK_BUTTONS_OK,
									  "Error, ingrese un valor entre 1 o 2");
	gtk_window_set_title(GTK_WINDOW(dialog), "Error");
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
	}else{
		gtk_widget_show_all(color);
		user=turn1;
		/*if(user==1){
			gtk_label_set_text(GTK_LABEL(label_turno), "Juega Usuario");
		}else{
			gtk_label_set_text(GTK_LABEL(label_turno), "Juega Maquina");
		}*/
		gtk_widget_hide(inicio_teclado);
	}
}
//Verificar si se ingresa correctamente el color y emite un mensaje de error si no esta correcto
void verificar_color(int color){
	if (color<1 || color>2){
		dialog = gtk_message_dialog_new(GTK_WINDOW(inicio_teclado),
									  GTK_DIALOG_DESTROY_WITH_PARENT,
									  GTK_MESSAGE_WARNING,
									  GTK_BUTTONS_OK,
									  "Error, ingrese un valor entre 1 o 2");
	gtk_window_set_title(GTK_WINDOW(dialog), "Error");
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
	}else{
		gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);
		gtk_widget_show_all(win_tablero);
		c1=color;
		/*if(c1==1){
			gtk_label_set_text(GTK_LABEL(label_color), "ROJO");
		}else{
			gtk_label_set_text(GTK_LABEL(label_color), "AZUL");
		}*/

		gtk_widget_hide(color_teclado);
	}
}
//Muestra la ventana para ingresar dimension
void boton_teclado(GtkWidget *widget, gpointer data){
	gtk_widget_show_all(dimension_teclado);
	gtk_widget_hide(dimension);

}
//Elige aleatoriamente la dimension del tablero
void boton_aleatorio(GtkWidget *widget, gpointer data){
	gtk_widget_hide(dimension);
	tam = (3+rand()%13);
	printf("dimension: %d",tam);
	gtk_widget_show_all(inicio);

}
//Ventana donde el usuario ingresa la dimension
void boton_dim(GtkWidget *widget, gpointer data){
	const gchar *dim=gtk_entry_get_text(GTK_ENTRY(dimension_ing));
	int y;
	printf ("dimmmmm:  %s\n", dim);
	y=atoi(dim);
	printf ("dimmmmm new:  %d\n", y);
	verificar_dimension(y);
}
//Abre la ventana de ingresar quien comienza
void boton_teclado11(GtkWidget *widget, gpointer data){
	gtk_widget_show_all(inicio_teclado);
	gtk_widget_hide(inicio);

}
//Ventana donde se ingresa quien comienza
void boton_teclado1(GtkWidget *widget, gpointer data){
	const gchar *turn3 = gtk_entry_get_text (GTK_ENTRY(inicio_tecl));

	int turn2;
	turn2=atoi(turn3);
	printf("\ninicia%d",turn2);
	verificar_inicio(turn2);
	gtk_widget_hide(inicio);
}
//Genera aleatoriamente quien comienza

void boton_aleatorio1(GtkWidget *widget, gpointer data){
	gtk_widget_hide(inicio);
	user=1+rand()%2;
	printf("inicia random%d\n",user);
	gtk_widget_show_all(color);
	/*if(user==1){
		gtk_label_set_text(GTK_LABEL(label_turno), "Juega Usuario");
	}else{
		gtk_label_set_text(GTK_LABEL(label_turno), "Juega Maquina");
	}*/

}

//Abre ventana de ingresar color
void boton_teclado22(GtkWidget *widget, gpointer data){
	gtk_widget_show_all(color_teclado);
	gtk_widget_hide(color);

}
//El usuario ingresa un color
void boton_teclado2(GtkWidget *widget, gpointer data){
	const gchar *c = gtk_entry_get_text (GTK_ENTRY(color_ingr));

	int color2;
	color2=atoi(c);
	printf("\ncolor%d",color2);
	verificar_color(color2);
	gtk_widget_hide(color);
}
//Opcion que genera aleatoriamente el color
void boton_aleatorio2(GtkWidget *widget, gpointer data){
	gtk_widget_hide(color);
	c1=1+rand()%2;
	printf("\nCOLOR ALEATORIO%d\n",c1);

	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);//llama a crear tablero
	gtk_widget_show_all(win_tablero);
	/*if(c1==1){
		gtk_label_set_text(GTK_LABEL(label_color), "ROJO");
	}else{
		gtk_label_set_text(GTK_LABEL(label_color), "AZUL");
	}*/
}
//Ventana de dialogo para instrucciones del juego
static void mostrar_ayuda(GtkWidget *widget, gpointer data) {
	gtk_dialog_run(GTK_DIALOG(dialogAyuda) );// mostramos la ventana de diálogo
	gtk_widget_hide(GTK_WIDGET(dialogAyuda) );	// escondemos la ventana
}
//Ventana de dialogo acerca de los autores
static void mostrar_acerca(GtkWidget *widget, gpointer data) {
	gtk_dialog_run(GTK_DIALOG(dialogAcerca) );// mostramos la ventana de diálogo
	gtk_widget_hide(GTK_WIDGET(dialogAcerca) );	// escondemos la ventana
}
//Ingresa nombre de usuario y maquina
void boton1_clicked_cb(GtkWidget *widget, gpointer data) {
	//gint ret;
	const gchar *buf;
	const gchar *buf1;
	//ret = gtk_window_show(GTK_DIALOG(dialog));
	//gtk_widget_show_all(dimension_teclado);

	buf = gtk_entry_get_text (GTK_ENTRY(text));
	buf1 = gtk_entry_get_text (GTK_ENTRY(text1));// leemos el texto introducido
	printf ("El nombre del usuario es: %s\n", buf);
	printf ("El nombre de la compu es: %s\n", buf1);
//Comprobamos que se ingrese dos nombres
	if(strlen(buf)<1 || strlen(buf1)<1){
			  dialog = gtk_message_dialog_new(GTK_WINDOW(ventana_principal),
			            GTK_DIALOG_DESTROY_WITH_PARENT,
			            GTK_MESSAGE_WARNING,
			            GTK_BUTTONS_OK,
			            "Debe completar los 2 nombres");
			  gtk_window_set_title(GTK_WINDOW(dialog), "ERROR");
			  gtk_dialog_run(GTK_DIALOG(dialog));
			  gtk_widget_destroy(dialog);
	}else{
		//Mostrar en el tablero los nombres
		gtk_label_set_text(GTK_LABEL(label_usuario1),"Nombre Usuario:");
		gtk_label_set_text(GTK_LABEL(label_pc1),"Nombre Pc:");
		gtk_label_set_text(GTK_LABEL(label_usuario),buf);
		gtk_label_set_text(GTK_LABEL(label_pc),buf1);

		gtk_widget_hide(GTK_WIDGET(ventana_principal) );//esconder ventana
		gtk_widget_show_all(dimension);

	}
	gtk_entry_set_text (GTK_ENTRY(text), "");	// vaciamos la entrada de texto
	gtk_entry_set_text (GTK_ENTRY(text1), "");	// vaciamos la entrada de texto
}

//Jugada del usuario
void tablero_cb(GtkWidget *event_box, GdkEventButton *event, gpointer data){
	user=1;
	gtk_label_set_text(GTK_LABEL(label_turno),"Juega Usuario");
	i = (GUINT_FROM_LE(event->y) / 75); //las imagenes tienen son 75x75pixeles
	j = (GUINT_FROM_LE(event->x) / 75);
	gchar *temp = g_strdup_printf("Presiono la imagen coordenada [%d,%d]", i,j);
	punto(i,j);
	gtk_label_set_text(GTK_LABEL(label_estado), temp);
	turno_pc();

}

//Creacion del tablero con interfaz y tablero logico
GtkWidget *crear_tablero(){
	int i, j;
	GtkWidget *imagen; //auxiliar para cargar la imagen
	GtkWidget *eventbox;
	eventbox = gtk_event_box_new();
	tablero = gtk_grid_new();
	n1=tam+(tam-1);//Formula  para agrandar tablero
	for (i = 0; i < n1; i++) {
		for (j = 0; j < n1; j++) {
			if (i%2==0 && j%2==0){
				imagen = gtk_image_new_from_file(imagenes[0]);
				gtk_grid_attach(GTK_GRID(tablero), GTK_WIDGET(imagen), j, i, 1, 1);
			}else{
				imagen = gtk_image_new_from_file(imagenes[1]);
				gtk_grid_attach(GTK_GRID(tablero), GTK_WIDGET(imagen), j, i, 1, 1);
			}
		}
	}

	for(i=0; i<n1; i++){

		for(j=0; j<n1; j++){
			if (i%2==0 && j%2==0){//colocar los astericos en las posiciones de fila y columna que son multiplos de 2
				matriz[i][j]='*';//carga astericos//////
			}else{
				matriz[i][j]='0';//cargado de la matriz
			}
			printf("%c",matriz[i][j]);//imprimir matriz
		}
		printf("\n");

	}

	gtk_container_add(GTK_CONTAINER(eventbox), tablero);
	g_signal_connect(eventbox, "button-press-event", G_CALLBACK(tablero_cb), tablero);
	return eventbox;
}
//Funcion para salir
void cerrar (GtkWidget *object, gpointer   user_data){
	 printf("%s", (char*)user_data);
	 gtk_main_quit();
}
//Funcion para salir 2
void cerrar1 (GtkWidget *object, gpointer   user_data){
	 printf("%s", (char*)user_data);
	 gtk_main_quit();
}
 int main (int argc, char *argv[])
 {

	srand(time(NULL));
	//GObject *menu_archivo_salir;	// identificador del objeto menu item salir
	//GObject *menu_archivo_abrir; 	// identificador del objeto menu item abrir
	///GObject *menu_archivo_salvar;	// identificador del objeto menu item salvar
	//GObject *menu_archivo_salvar_como;// identificador del objeto menu item salvar como
	// identificador del objeto menu item salir


    guint ret;

    GError *error = NULL;

    gtk_init (&argc, &argv);

	builder = gtk_builder_new();
	//Se carga el builder
	ret = gtk_builder_add_from_file(builder, "lab4.glade", &error);
	if (ret == 0) {
		g_print("Error en la función gtk_builder_add_from_file:\n%s", error->message);
		return 1;
	}

	dialogAyuda = GTK_WIDGET(gtk_builder_get_object(builder, "ayudaa"));// leemos la ventana de diálogo de ayuda para el juego
	dialogAcerca = GTK_WIDGET(gtk_builder_get_object(builder, "acerca"));// leemos la ventana de diálogo de acerca para el juego
	text = GTK_WIDGET(gtk_builder_get_object(builder, "selnombre1"));
	text1 = GTK_WIDGET(gtk_builder_get_object(builder, "selnombre2"));
	inicio_tecl = GTK_WIDGET(gtk_builder_get_object(builder, "inicio_tecl"));
	color_ingr = GTK_WIDGET(gtk_builder_get_object(builder, "color_ingr"));
	dimension_ing=GTK_WIDGET(gtk_builder_get_object(builder,"dimension_ing"));

	char mensaje[20] = "el juego termino";
	char mensaje1[20] = "el juego termino";

	//Ventana principal
	ventana_principal = GTK_WIDGET(gtk_builder_get_object(builder, "ventana_principal"));
	g_signal_connect (ventana_principal, "destroy", G_CALLBACK (cerrar), mensaje);

	win_tablero = GTK_WIDGET(gtk_builder_get_object(builder, "tablero"));
	//g_signal_connect (win_tablero, "destroy", G_CALLBACK (cerrar), mensaje);

	//otras ventanas
	dimension = GTK_WIDGET(gtk_builder_get_object(builder, "dimension"));
	g_signal_connect(dimension, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	dimension_teclado = GTK_WIDGET(gtk_builder_get_object(builder, "dimension_teclado"));
	g_signal_connect(dimension_teclado, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	inicio = GTK_WIDGET(gtk_builder_get_object(builder, "inicio"));
	g_signal_connect(inicio, "destroy", G_CALLBACK (gtk_main_quit), NULL);


	inicio_teclado = GTK_WIDGET(gtk_builder_get_object(builder, "inicio_teclado"));
	g_signal_connect(inicio_teclado, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	color = GTK_WIDGET(gtk_builder_get_object(builder, "color"));
	g_signal_connect(color, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	color_teclado = GTK_WIDGET(gtk_builder_get_object(builder, "color_teclado"));
	g_signal_connect(color_teclado, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	//Box donde estara el Tablero
	box_tablero = GTK_WIDGET(gtk_builder_get_object(builder, "box_tablero"));


	//Labels


	bienvenida = GTK_WIDGET(gtk_builder_get_object(builder, "textobienvenida"));
	titulo = GTK_WIDGET(gtk_builder_get_object(builder, "texto_titulo"));
	label_turno = GTK_WIDGET(gtk_builder_get_object(builder, "label_turno"));
	label_estado = GTK_WIDGET(gtk_builder_get_object(builder, "label_estado"));
	label_inferior = GTK_WIDGET(gtk_builder_get_object(builder, "label_inferior"));
	label_color = GTK_WIDGET(gtk_builder_get_object(builder, "label_color"));
	label_mensaje = GTK_WIDGET(gtk_builder_get_object(builder, "label_mensaje"));
	label_usuario = GTK_WIDGET(gtk_builder_get_object(builder, "label_usuario"));
	label_pc = GTK_WIDGET(gtk_builder_get_object(builder, "label_pc"));
	label_usuario1 = GTK_WIDGET(gtk_builder_get_object(builder, "label_usuario1"));
	label_pc1 = GTK_WIDGET(gtk_builder_get_object(builder, "label_pc1"));
	puntaje_usuario = GTK_WIDGET(gtk_builder_get_object(builder, "puntaje_usuario"));
	puntaje_maquina = GTK_WIDGET(gtk_builder_get_object(builder, "puntaje_maquina"));
	empate = GTK_WIDGET(gtk_builder_get_object(builder, "empate"));


	//botoneessss

	////
	teclado = GTK_WIDGET(gtk_builder_get_object(builder, "teclado"));
	g_signal_connect(teclado, "clicked", G_CALLBACK (boton_teclado), NULL);

	aleatorio = GTK_WIDGET(gtk_builder_get_object(builder, "aleatorio"));
	g_signal_connect(aleatorio, "clicked", G_CALLBACK (boton_aleatorio), NULL);

	teclado1 = GTK_WIDGET(gtk_builder_get_object(builder, "teclado1"));
	g_signal_connect(teclado1, "clicked", G_CALLBACK (boton_teclado11), NULL);

	aleatorio1 = GTK_WIDGET(gtk_builder_get_object(builder, "aleatorio1"));
	g_signal_connect(aleatorio1, "clicked", G_CALLBACK (boton_aleatorio1), NULL);

	teclado2 = GTK_WIDGET(gtk_builder_get_object(builder, "teclado2"));
	g_signal_connect(teclado2, "clicked", G_CALLBACK (boton_teclado22), NULL);

	aleatorio2 = GTK_WIDGET(gtk_builder_get_object(builder, "aleatorio2"));
	g_signal_connect(aleatorio2, "clicked", G_CALLBACK (boton_aleatorio2), NULL);

	////
	siguiente = GTK_WIDGET(gtk_builder_get_object(builder, "siguiente"));
	g_signal_connect(siguiente, "clicked", G_CALLBACK (boton1_clicked_cb), NULL);

	siguiente1=GTK_WIDGET(gtk_builder_get_object(builder,"siguiente1"));
	g_signal_connect(siguiente1,"clicked", G_CALLBACK(boton_dim),NULL);

	siguiente2=GTK_WIDGET(gtk_builder_get_object(builder,"siguiente2"));
	g_signal_connect(siguiente2,"clicked", G_CALLBACK(boton_teclado1),NULL);

	siguiente3=GTK_WIDGET(gtk_builder_get_object(builder,"siguiente3"));
	g_signal_connect(siguiente3,"clicked", G_CALLBACK(boton_teclado2),NULL);

	salir_tablero=GTK_WIDGET(gtk_builder_get_object(builder,"salir_tablero"));
	g_signal_connect(salir_tablero,"activate", G_CALLBACK(cerrar1),mensaje1);


	menu_mostrar_acerca = GTK_WIDGET(gtk_builder_get_object(builder, "acercade"));
	g_signal_connect(menu_mostrar_acerca, "activate", G_CALLBACK (mostrar_acerca), NULL);

	menu_mostrar_ayuda = GTK_WIDGET(gtk_builder_get_object(builder, "menuitem2"));
	g_signal_connect(menu_mostrar_ayuda, "activate", G_CALLBACK (mostrar_ayuda), NULL);

	menu_salir = GTK_WIDGET(gtk_builder_get_object(builder, "menuitem3"));
	g_signal_connect(menu_salir, "activate", G_CALLBACK (cerrar), mensaje);





    /* Connect the destroy signal of the window to gtk_main_quit
     * When the window is about to be destroyed we get a notification and
     * stop the main GTK+ loop
     */
	g_signal_connect (ventana_principal, "destroy", G_CALLBACK (cerrar), mensaje);
    //g_signal_connect (window, "destroy", G_CALLBACK (cerrar), mensaje);

    /* make sure that everything, window and label, are visible */
    gtk_widget_show_all (ventana_principal);


    /* start the main loop, and let it rest there until the application is closed */
    gtk_main ();

    return 0;
 }

